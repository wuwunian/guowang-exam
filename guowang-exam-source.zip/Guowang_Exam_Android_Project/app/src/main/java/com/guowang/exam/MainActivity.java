package com.guowang.exam;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    WebView view = new WebView(this);
    view.setWebViewClient(new WebViewClient());
    WebSettings settings = view.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(true);
    settings.setSupportZoom(false);
    view.loadUrl("file:///android_asset/index.html");
    setContentView(view);
  }
  @Override public void onBackPressed() { WebView v=(WebView)findViewById(android.R.id.content); super.onBackPressed(); }
}
