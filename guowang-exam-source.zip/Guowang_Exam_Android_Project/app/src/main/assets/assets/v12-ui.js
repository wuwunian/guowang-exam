import {
  createReferencePanel,
  createCultureReview,
  culturePending,
} from "./v13-reference-ui.js";
import { createCalculator } from "./v13-calculator.js";
import {
  validProof,
  references,
  configFor,
  contextItems,
} from "./v13-match.js";
import {
  MODULES,
  moduleOf,
  typeOf,
  same,
  validate,
  notice,
} from "./v11-core.js";
import {
  catalog,
  filter,
  due,
  review,
  overview,
  suggestion,
  revision,
  localDay,
  countdown,
  weaknesses,
} from "./v12-logic.js";
import { buildPrompt } from "./v12-prompt.js";
const TYPES = {
  single: "单选",
  multi: "多选",
  judge: "判断",
  data: "资料单选",
};
function download(value, name) {
  const url = URL.createObjectURL(
      new Blob([value], { type: "text/plain;charset=utf-8" }),
    ),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
export function createCenter(React, api) {
  const h = React.createElement,
    { useState, useEffect, useMemo, useRef } = React;
  const ReferencePanel = createReferencePanel(React, api),
    CultureReview = createCultureReview(React, api),
    Calculator = createCalculator(React, api);
  const B = (label, action, p = {}) =>
    h("button", { type: "button", onClick: action, ...p }, label);
  const S = (value, change, opts, label) =>
    h(
      "select",
      { value, onChange: (e) => change(e.target.value), "aria-label": label },
      ...opts.map(([v, t]) => h("option", { value: v, key: v }, t)),
    );
  const T = (value) => h(api.Tex, { tex: value || "" });
  function material(m) {
    return (
      m &&
      h(
        "div",
        { className: "v12-material" },
        ...m.paras.map((p, i) => h("p", { key: i }, T(p))),
        ...(m.images || []).map((src, i) =>
          h("img", { src, key: i, alt: "材料图片" }),
        ),
      )
    );
  }
  function question(e) {
    return h(
      "article",
      { className: "v12-question" },
      h("b", null, `${e.paper.title} · 第${e.q.no}题`),
      material(e.material),
      h("p", null, T(e.q.stem)),
      ...(e.q.images || []).map((src, i) =>
        h("img", { src, key: i, alt: "题图" }),
      ),
      h(
        "ul",
        null,
        ...e.q.options.map((o) =>
          h("li", { key: o.key }, o.key + ". ", T(o.text)),
        ),
      ),
      h(
        "div",
        { className: "v12-explanation" },
        h("b", null, "答案：" + e.q.answer.join(" ")),
        h(
          "div",
          null,
          T(
            (e.q.explanation || "原文件未提供解析").replace(
              /^\s*【[^】]+】\s*/,
              "",
            ),
          ),
        ),
      ),
    );
  }
  function Prompt({ papers = [] }) {
    const [mode, setMode] = useState("exam"),
      [context, setContext] = useState("");
    const sourceRefs = references(papers, configFor(papers)),
      bookNames = [...new Set(sourceRefs.map((r) => r.paper.title))];
    const sourceNote = sourceRefs.length
      ? "软件当前选定来源库：" +
        bookNames.join("、") +
        "；企业文化参考记录" +
        sourceRefs.length +
        "条。这里只是目录元数据，AI还需收到导出的参考TXT或原文件，不得据此声称已读取本机题库。"
      : "软件当前未选定可用的企业文化来源。未拿到来源内容时企业文化须保留待核对，不能凭语义确认。";
    const prompt = buildPrompt(
      mode,
      (context ? context + "\n" : "") + sourceNote,
    );
    async function copy() {
      try {
        if (navigator.clipboard?.writeText)
          await navigator.clipboard.writeText(prompt);
        else {
          const t = document.createElement("textarea");
          t.value = prompt;
          document.body.append(t);
          t.select();
          if (!document.execCommand("copy")) throw Error();
          t.remove();
        }
        notice("完整提示词已复制");
      } catch {
        notice("请在下方提示词框中全选后复制", {}, "error");
      }
    }
    return h(
      "section",
      null,
      h("h2", null, "生成可导入Word的完整提示词"),
      h(
        "p",
        null,
        "连同原卷、评分说明、对应答案，以及来源库导出的企业文化参考TXT交给能生成DOCX的AI。软件本身离线，不会自动把你的题库发给AI。",
      ),
      h(
        "div",
        { className: "v12-tools" },
        S(
          mode,
          setMode,
          [
            ["exam", "计时考试"],
            ["culture", "无计时题库练习"],
          ],
          "提示词模式",
        ),
        B("复制完整提示词", copy),
        B("下载提示词TXT", () =>
          download(prompt, "国网Word制作完整提示词.txt"),
        ),
      ),
      h(
        "label",
        null,
        "可选：来源与特殊要求",
        h("textarea", {
          rows: 2,
          value: context,
          onChange: (e) => setContext(e.target.value),
        }),
      ),
      h("textarea", {
        className: "v12-prompt",
        value: prompt,
        readOnly: true,
        "aria-label": "完整Word提示词",
      }),
    );
  }
  function Modules({ papers, setPapers }) {
    const [id, setId] = useState(papers[0]?.id || ""),
      [items, setItems] = useState([]),
      [pending, setPending] = useState(true),
      [search, setSearch] = useState(""),
      [chosen, setChosen] = useState([]),
      [note, setNote] = useState(""),
      [batch, setBatch] = useState("企业文化"),
      [value, setValue] = useState(""),
      [ack, setAck] = useState(false),
      [inspect, setInspect] = useState(null),
      [page, setPage] = useState(0),
      [replay, setReplay] = useState(true);
    const paper = papers.find((p) => p.id === id);
    useEffect(() => {
      setItems(contextItems(structuredClone(paper?.items || [])));
      setChosen([]);
      setNote("");
      setInspect(null);
      setPage(0);
    }, [id, papers]);
    const originalProgress = paper ? api.progress(paper.id) : null,
      canReplay =
        paper?.mode === "exam" &&
        originalProgress?.submitted &&
        items.every(
          (q, i) => q.type !== "question" || q.score === paper.items[i]?.score,
        );
    const sum = overview(items),
      qs = items.filter((q) => q.type === "question"),
      list = qs.filter(
        (q) =>
          (!pending ||
            moduleOf(q) === "未分类" ||
            (paper?.mode !== "culture" && culturePending(q, papers))) &&
          (!search || `${q.no} ${q.stem}`.includes(search)),
      ),
      errors = paper ? validate({ ...paper, items }).errors : [];
    function change(no, patch) {
      setItems((old) =>
        old.map((q) =>
          q.type === "question" && q.no === no ? { ...q, ...patch } : q,
        ),
      );
    }
    function accept() {
      if (!chosen.length) return notice("请先选题", {}, "error");
      setItems((old) =>
        old.map((q) => {
          if (q.type !== "question" || !chosen.includes(q.no)) return q;
          const s = suggestion(q, papers);
          return s?.module
            ? {
                ...q,
                module: s.module,
                moduleConfirmed: true,
                moduleReviewSource: "user-confirmed",
                moduleReason: s.reason,
                cultureMatch: s.module === "企业文化" ? s.proof : null,
              }
            : q;
        }),
      );
      setChosen([]);
    }
    function save() {
      try {
        if (sum.pending && !ack)
          throw Error("仍有未分类，请继续核对或明确确认保留");
        const next = revision(paper, items, note, papers);
        if (canReplay && replay) {
          next.analysisReplayOf = paper.analysisReplayOf || paper.id;
          next.title = next.title.replace(/）$/, "·分类复核）");
          next.progressOriginNote = "沿用原始交卷快照重新分类，不是新的考试";
        }
        const all = [next, ...papers];
        api.savePapers(all);
        if (next.analysisReplayOf) {
          const answers = structuredClone(
            originalProgress.submittedAnswers || originalProgress.answers || {},
          );
          if (
            !api.saveProgress(next.id, {
              started: true,
              submitted: true,
              endTime: null,
              cur: 1,
              answers,
              submittedAnswers: structuredClone(answers),
              flags: structuredClone(originalProgress.flags || {}),
              judged: structuredClone(originalProgress.judged || {}),
              finishedAt: originalProgress.finishedAt || Date.now(),
              analysisOnly: true,
              sourcePaperId: next.analysisReplayOf,
            })
          ) {
            api.savePapers(papers);
            throw Error(
              "分类复核作答未能保存，已恢复原题库列表，请先备份并检查存储空间",
            );
          }
        }
        setPapers(all);
        setId(next.id);
        window.dispatchEvent(new Event("v12-papers-updated"));
        notice("已另存修订版，原卷与旧成绩保持不变");
      } catch (e) {
        notice(e.message, {}, "error");
      }
    }
    return h(
      "section",
      null,
      h("h2", null, "模块分值核对中心"),
      h(
        "p",
        null,
        "先核对企业文化来源，再按实际设问判断其他八科。分值仍逐题累加；不会按你贴的分数反推标签或凑配分。",
      ),
      S(
        id,
        (v) => {
          const changed =
            paper &&
            items.some(
              (q, i) =>
                q.type === "question" &&
                (moduleOf(q) !== moduleOf(paper.items[i]) ||
                  q.score !== paper.items[i].score),
            );
          if (
            !changed ||
            window.confirm("切换将丢弃当前未保存草稿，是否继续？")
          )
            setId(v);
        },
        papers.map((p) => [p.id, p.title]),
        "核对试卷",
      ),
      paper
        ? h(
            React.Fragment,
            null,
            paper.mode !== "culture" &&
              qs.some((q) => culturePending(q, papers)) &&
              h(
                "div",
                { className: "v12-warning" },
                "存在原标企业文化但来源尚未核验的题，请通过来源对照补全凭证，或保留未分类；旧成绩不会自动被改动。",
              ),
            h(
              "div",
              { className: "v12-band" },
              `实算 ${sum.total} / 声明 ${paper.full_score}分；未分类 ${sum.pending}题、${sum.pendingFull}分。` +
                (sum.pending ? "模块分值尚未完整。" : "九模块分类已覆盖整卷。"),
            ),
            h(
              "div",
              { className: "v12-grid" },
              ...sum.modules.map((r) =>
                h(
                  "div",
                  { key: r.name },
                  h("b", null, r.name),
                  h("span", null, `${r.count}题 · ${r.full}分`),
                ),
              ),
            ),
            h(
              "div",
              { className: "v12-tools" },
              h(
                "label",
                null,
                h("input", {
                  type: "checkbox",
                  checked: pending,
                  onChange: (e) => {
                    setPending(e.target.checked);
                    setPage(0);
                  },
                }),
                "只看未分类或企业来源待核对",
              ),
              h("input", {
                value: search,
                onChange: (e) => {
                  setSearch(e.target.value);
                  setPage(0);
                },
                placeholder: "题号或题干",
                "aria-label": "核对题目搜索",
              }),
              B(`选中当前筛选的${list.length}题`, () =>
                setChosen(list.map((q) => q.no)),
              ),
              B("清空选择", () => setChosen([])),
              B("采用选中题的分类建议", accept),
            ),
            h(
              "div",
              { className: "v12-tools" },
              S(
                batch,
                setBatch,
                MODULES.map((m) => [m, m]),
                "批量分类模块",
              ),
              B("选中题统一归入此模块", () => {
                if (batch === "企业文化") {
                  if (!chosen.length) return notice("请先选题", {}, "error");
                  setItems((old) =>
                    old.map((q) => {
                      if (q.type !== "question" || !chosen.includes(q.no))
                        return q;
                      const hit = suggestion(q, papers);
                      return hit?.module === "企业文化" && hit.proof
                        ? {
                            ...q,
                            module: "企业文化",
                            moduleConfirmed: true,
                            moduleReviewSource: "user-confirmed",
                            moduleReason: hit.reason,
                            cultureMatch: hit.proof,
                          }
                        : q;
                    }),
                  );
                  setChosen([]);
                  return notice(
                    "企业文化仅采用精确来源命中；未命中题保持原状，请逐题核对。",
                  );
                }
                if (!chosen.length) return notice("请先选题", {}, "error");
                setItems((old) =>
                  old.map((q) =>
                    q.type === "question" && chosen.includes(q.no)
                      ? {
                          ...q,
                          module: batch,
                          moduleConfirmed: true,
                          moduleReviewSource: "user-confirmed",
                          cultureMatch: null,
                        }
                      : q,
                  ),
                );
                setChosen([]);
              }),
              h("input", {
                type: "number",
                min: 0.0001,
                step: 0.0001,
                value,
                onChange: (e) => setValue(e.target.value),
                placeholder: "有依据的统一分值",
                "aria-label": "批量分值",
              }),
              B("按依据设置选中题分值", () => {
                if (
                  !chosen.length ||
                  !note.trim() ||
                  !/^\d+(?:\.\d{1,4})?$/.test(value) ||
                  Number(value) <= 0
                )
                  return notice(
                    "请选题、填写正分值，并在下方说明评分依据",
                    {},
                    "error",
                  );
                if (
                  !window.confirm(
                    `把选中的${chosen.length}题统一设为${value}分？这会覆盖草稿原分值。`,
                  )
                )
                  return;
                setItems((old) =>
                  old.map((q) =>
                    q.type === "question" && chosen.includes(q.no)
                      ? { ...q, score: Number(value), scoreSource: note }
                      : q,
                  ),
                );
              }),
            ),
            h(
              "div",
              { className: "v12-scroll" },
              h(
                "table",
                { className: "v11-table" },
                h(
                  "thead",
                  null,
                  h(
                    "tr",
                    null,
                    ...[
                      "选择",
                      "题号/题型",
                      "题干",
                      "模块",
                      "建议及依据",
                      "分值",
                      "原题",
                    ].map((t) => h("th", { key: t }, t)),
                  ),
                ),
                h(
                  "tbody",
                  null,
                  ...list.slice(page * 40, page * 40 + 40).map((q) => {
                    const s = suggestion(q, papers);
                    return h(
                      "tr",
                      { key: q.no },
                      h(
                        "td",
                        null,
                        h("input", {
                          type: "checkbox",
                          checked: chosen.includes(q.no),
                          "aria-label": `选择第${q.no}题`,
                          onChange: (e) =>
                            setChosen((old) =>
                              e.target.checked
                                ? [...old, q.no]
                                : old.filter((v) => v !== q.no),
                            ),
                        }),
                      ),
                      h("td", null, q.no + " / " + TYPES[q.qtype]),
                      h("td", { title: q.stem }, q.stem.slice(0, 60)),
                      h(
                        "td",
                        null,
                        S(
                          moduleOf(q),
                          (m) =>
                            change(q.no, {
                              module: m,
                              moduleConfirmed: true,
                              moduleReviewSource: "user-confirmed",
                              cultureMatch:
                                m === "企业文化" ? q.cultureMatch : null,
                            }),
                          ["未分类", ...MODULES].map((m) => [m, m]),
                          `第${q.no}题模块`,
                        ),
                      ),
                      h(
                        "td",
                        null,
                        s
                          ? h(
                              React.Fragment,
                              null,
                              h("b", null, s.module || "待核对"),
                              h("small", null, s.reason),
                              s.module &&
                                B("采用建议", () =>
                                  change(q.no, {
                                    module: s.module,
                                    moduleConfirmed: true,
                                    moduleReviewSource: "user-confirmed",
                                    moduleReason: s.reason,
                                    cultureMatch:
                                      s.module === "企业文化" ? s.proof : null,
                                  }),
                                ),
                            )
                          : "需人工核对",
                      ),
                      h(
                        "td",
                        null,
                        h("input", {
                          type: "number",
                          step: 0.0001,
                          min: 0.0001,
                          value: Number.isFinite(q.score) ? q.score : "",
                          "aria-label": `第${q.no}题分值`,
                          onChange: (e) =>
                            change(q.no, {
                              score:
                                e.target.value === ""
                                  ? NaN
                                  : Number(e.target.value),
                            }),
                        }),
                      ),
                      h(
                        "td",
                        null,
                        B("原题与来源", () => setInspect(q)),
                      ),
                    );
                  }),
                ),
              ),
            ),
            h(
              "div",
              { className: "v12-tools" },
              B("上一页", () => setPage(Math.max(0, page - 1)), {
                disabled: !page,
              }),
              h(
                "span",
                null,
                `${page + 1} / ${Math.max(1, Math.ceil(list.length / 40))}页`,
              ),
              B("下一页", () => setPage(page + 1), {
                disabled: (page + 1) * 40 >= list.length,
              }),
            ),
            inspect &&
              h(
                "div",
                { className: "v12-card" },
                B("收起原题", () => setInspect(null)),
                question({
                  q: inspect,
                  paper,
                  material: paper.items.find(
                    (m) =>
                      m.type === "material" &&
                      inspect.no >= m.range?.from &&
                      inspect.no <= m.range?.to,
                  ),
                }),
                h(
                  "p",
                  null,
                  "分值依据：" +
                    (inspect.scoreSource || "未提供单独依据，请对照原卷"),
                ),
                h(
                  "p",
                  null,
                  "分类依据：" + (inspect.moduleReason || "未提供单独依据"),
                ),
                inspect.originalNo &&
                  h("p", null, "原编号：" + inspect.originalNo),
                h(CultureReview, {
                  paper: { ...paper, items },
                  q:
                    items.find(
                      (q) => q.type === "question" && q.no === inspect.no,
                    ) || inspect,
                  papers,
                  onConfirm: (proof) => {
                    change(inspect.no, {
                      module: "企业文化",
                      moduleConfirmed: true,
                      moduleReviewSource: "user-confirmed",
                      cultureMatch: proof,
                      moduleReason:
                        "企业文化来源：" +
                        proof.referenceTitle +
                        " 第" +
                        proof.referenceNo +
                        "题（" +
                        proof.kind +
                        "）",
                    });
                    setInspect(null);
                  },
                }),
              ),
            h(
              "label",
              null,
              "核对依据（改分须说明评分来源）",
              h("textarea", {
                value: note,
                onChange: (e) => setNote(e.target.value),
                rows: 2,
                "aria-label": "分类分值核对依据",
              }),
            ),
            sum.pending > 0 &&
              h(
                "label",
                null,
                h("input", {
                  type: "checkbox",
                  checked: ack,
                  onChange: (e) => setAck(e.target.checked),
                }),
                "接受保留未分类及分值缺口",
              ),
            errors.length > 0 &&
              h("div", { className: "v12-warning" }, errors.join("\n")),
            canReplay &&
              h(
                "label",
                { className: "v13-replay" },
                h("input", {
                  type: "checkbox",
                  checked: replay,
                  onChange: (e) => setReplay(e.target.checked),
                }),
                "仅改分类时沿用原始作答生成分类复核报告（不是新考试，原报告保留）",
              ),
            !canReplay &&
              originalProgress?.submitted &&
              h(
                "p",
                { className: "v12-note" },
                "分值改变时不自动沿用旧成绩；请按新评分规则重新验证。",
              ),
            h(
              "div",
              { className: "v12-tools" },
              B("另存修订版", save, { disabled: !!errors.length }),
              B("导出模块分值CSV", () =>
                download(
                  "\ufeff" +
                    [
                      ["模块", "题数", "满分"],
                      ...sum.modules.map((r) => [r.name, r.count, r.full]),
                      ["未分类", sum.pending, sum.pendingFull],
                      ["总计", qs.length, sum.total],
                    ]
                      .map((r) => r.join(","))
                      .join("\r\n"),
                  "模块分值核对.csv",
                ),
              ),
            ),
            h(
              "p",
              { className: "v12-note" },
              "更正声明满分请重新导入Word。仅改分类可沿用冻结作答重排模块分析，不计作新考试；改分不自动重算旧成绩。",
            ),
          )
        : h("p", null, "请先在首页导入题库。"),
    );
  }
  function Dashboard({ entries, data, update, start }) {
    const settings = data.settings || {},
      events = data.events || [],
      today = events.filter((e) => localDay(e.at) === localDay()),
      todo = entries.filter((e) => due(e)),
      days = countdown(Date.now(), settings.examDate),
      weak = weaknesses(entries);
    return h(
      "section",
      null,
      h("h2", null, "今日备考"),
      h(
        "div",
        { className: "v12-metrics" },
        ...[
          ["今日训练", `${today.length} / ${settings.goal || 20}题`],
          ["到期复习", `${todo.length}题`],
          ["收藏", `${entries.filter((e) => e.record.favorite).length}题`],
          [
            "考试倒计时",
            days === null ? "未设置" : days < 0 ? "日期已过" : `${days}天`,
          ],
        ].map(([a, b]) =>
          h("div", { key: a }, h("span", null, a), h("strong", null, b)),
        ),
      ),
      h(
        "div",
        { className: "v12-tools" },
        B("开始今日复习", () => start(todo.slice(0, settings.goal || 20))),
        h(
          "label",
          null,
          "每日目标题数 ",
          h("input", {
            type: "number",
            min: 1,
            max: 500,
            value: settings.goal || 20,
            onChange: (e) => {
              const goal = Number(e.target.value);
              if (Number.isInteger(goal) && goal > 0 && goal <= 500)
                update({ ...data, settings: { ...settings, goal } });
            },
          }),
        ),
        h(
          "label",
          null,
          "考试日期 ",
          h("input", {
            type: "date",
            value: settings.examDate || "",
            onChange: (e) =>
              update({
                ...data,
                settings: { ...settings, examDate: e.target.value },
              }),
          }),
        ),
      ),
      h(
        "p",
        { className: "v12-note" },
        "复习间隔按表现安排1、3、7、14、30天；答错或没把握回到短间隔。仅在软件内显示，不发送系统提醒，不保证记忆效果。",
      ),
      h("h3", null, "最近7天练习量"),
      h(
        "div",
        { className: "v12-week" },
        ...Array.from({ length: 7 }, (_, i) => {
          const d = new Date();
          d.setDate(d.getDate() - 6 + i);
          const day = localDay(d.getTime()),
            n = events.filter((e) => localDay(e.at) === day).length;
          return h(
            "div",
            { key: day },
            h("span", null, day.slice(5)),
            h("i", {
              style: {
                height: Math.min(100, (n / (settings.goal || 20)) * 100) + "px",
              },
            }),
            h("b", null, n),
          );
        }),
      ),
      h("h3", null, "优先补练的模块"),
      h(
        "p",
        { className: "v12-note" },
        "按当前交卷快照和已提交题库练习统计。未答单列，不直接认定知识薄弱；先看已答失分率，样本少仅作线索。未分类不混入九模块。",
      ),
      weak.length
        ? h(
            "table",
            { className: "v11-table" },
            h(
              "thead",
              null,
              h(
                "tr",
                null,
                ...[
                  "模块",
                  "已答 / 未答",
                  "失分 / 满分",
                  "已答失分率",
                  "练习",
                ].map((t) => h("th", { key: t }, t)),
              ),
            ),
            h(
              "tbody",
              null,
              ...weak.map((r) =>
                h(
                  "tr",
                  { key: r.name },
                  h("td", null, r.name),
                  h(
                    "td",
                    null,
                    `${r.answered} / ${r.miss}` +
                      (r.answered < 3 ? "（样本少）" : ""),
                  ),
                  h("td", null, `${r.lost} / ${r.full}`),
                  h(
                    "td",
                    null,
                    r.rate === null
                      ? "—"
                      : Math.round(r.rate * 10000) / 100 + "%",
                  ),
                  h(
                    "td",
                    null,
                    B("专项训练", () =>
                      start(entries.filter((e) => e.module === r.name)),
                    ),
                  ),
                ),
              ),
            ),
          )
        : h("p", null, "完成一次考试或题库练习后显示模块表现。"),
    );
  }
  function Library({ entries, data, update, start }) {
    const [f, setF] = useState({
        paper: "",
        module: "",
        type: "",
        status: "due",
        text: "",
      }),
      [count, setCount] = useState(20),
      [random, setRandom] = useState(false),
      [inspect, setInspect] = useState(null),
      [printing, setPrinting] = useState(false),
      ref = useRef(null);
    const list = filter(entries, f);
    async function print() {
      setPrinting(true);
      await new Promise((r) => setTimeout(r, 80));
      document.body.classList.add("v12-printing");
      try {
        await document.fonts.ready;
        await Promise.all(
          [...ref.current.querySelectorAll("img")].map((img) =>
            img.decode().catch(() => {}),
          ),
        );
        const r = await api.exportPDF(ref.current, "国网复习清单");
        if (!r.ok && !r.canceled) notice(r.error || "导出失败", {}, "error");
      } finally {
        document.body.classList.remove("v12-printing");
        setPrinting(false);
      }
    }
    return h(
      "section",
      null,
      h("h2", null, "错题复习与专项训练"),
      h(
        "div",
        { className: "v12-tools" },
        S(
          f.paper,
          (v) => setF({ ...f, paper: v }),
          [
            ["", "全部题库（含修订版）"],
            ...Array.from(
              new Map(entries.map((e) => [e.paper.id, e.paper])).values(),
            ).map((p) => [p.id, p.title]),
          ],
          "练习题库筛选",
        ),
        S(
          f.status,
          (v) => setF({ ...f, status: v }),
          [
            ["due", "到期复习"],
            ["wrong", "错答或未答"],
            ["favorite", "收藏"],
            ["uncertain", "没把握"],
            ["all", "全部题目"],
          ],
          "复习状态筛选",
        ),
        S(
          f.module,
          (v) => setF({ ...f, module: v }),
          [
            ["", "全部模块"],
            ...MODULES.map((m) => [m, m]),
            ["未分类", "未分类"],
          ],
          "练习模块筛选",
        ),
        S(
          f.type,
          (v) => setF({ ...f, type: v }),
          [
            ["", "全部题型"],
            ["single", "单选（含资料）"],
            ["multi", "多选"],
            ["judge", "判断"],
          ],
          "练习题型筛选",
        ),
        h("input", {
          value: f.text,
          onChange: (e) => setF({ ...f, text: e.target.value }),
          placeholder: "题干、选项、解析或笔记",
          "aria-label": "练习搜索",
        }),
      ),
      h(
        "div",
        { className: "v12-tools" },
        h("span", null, `匹配 ${list.length}题`),
        S(
          String(count),
          (v) => setCount(Number(v)),
          [10, 20, 50, 100, 500].map((n) => [String(n), `每次${n}题`]),
          "训练题量",
        ),
        h(
          "label",
          null,
          h("input", {
            type: "checkbox",
            checked: random,
            onChange: (e) => setRandom(e.target.checked),
          }),
          "随机题序（选项不打乱）",
        ),
        B(
          "开始当前筛选训练",
          () => {
            const a = [...list];
            if (random)
              for (let i = a.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [a[i], a[j]] = [a[j], a[i]];
              }
            start(a.slice(0, count));
          },
          { disabled: !list.length },
        ),
        B("导出当前复习清单PDF", print, { disabled: !list.length || printing }),
      ),
      h(
        "p",
        { className: "v12-note" },
        "可指定单套题库避免原卷与修订版重复训练。原考试与复习表现分别保留；复习答对不会改动原成绩。列表预览前100题，训练与导出使用筛选结果。",
      ),
      h(
        "div",
        { className: "v12-list" },
        ...list.slice(0, 100).map((e) =>
          h(
            "div",
            { key: e.key },
            h(
              "small",
              null,
              `${e.paper.title} · ${e.q.no} · ${e.module} · ${TYPES[e.q.qtype]}`,
            ),
            h("p", null, e.q.stem.slice(0, 140)),
            B(e.record.favorite ? "取消收藏" : "收藏", () =>
              update({
                ...data,
                records: {
                  ...data.records,
                  [e.key]: { ...e.record, favorite: !e.record.favorite },
                },
              }),
            ),
            B("查看与笔记", () => setInspect(e)),
          ),
        ),
      ),
      inspect &&
        h(
          "div",
          { className: "v12-card" },
          B("收起原题", () => setInspect(null)),
          question(inspect),
          h(
            "label",
            null,
            "复习笔记",
            h("textarea", {
              rows: 3,
              value: data.records?.[inspect.key]?.note || "",
              onChange: (e) =>
                update({
                  ...data,
                  records: {
                    ...data.records,
                    [inspect.key]: {
                      ...data.records?.[inspect.key],
                      note: e.target.value,
                    },
                  },
                }),
            }),
          ),
        ),
      printing &&
        h(
          "div",
          { className: "v12-export", ref },
          h("h1", null, "国网错题复习清单"),
          h(
            "p",
            null,
            `共${list.length}题；含原始答案与复习笔记，不代表新考试成绩。`,
          ),
          ...list.map((e) =>
            h(
              "section",
              { key: e.key },
              question(e),
              e.record.note && h("p", null, "复习笔记：" + e.record.note),
            ),
          ),
        ),
    );
  }
  function Practice({ entries, data, update, session, setSession }) {
    const [picked, setPicked] = useState(session.picked || []),
      [submitted, setSubmitted] = useState(!!session.submitted),
      [uncertain, setUncertain] = useState(!!session.uncertain),
      [reason, setReason] = useState(session.reason || "");
    useEffect(() => {
      setPicked(session.picked || []);
      setSubmitted(!!session.submitted);
      setUncertain(!!session.uncertain);
      setReason(session.reason || "");
    }, [session.index, session.keys]);
    const e = entries.find((e) => e.key === session.keys[session.index]);
    if (!e)
      return h(
        "section",
        null,
        h("p", null, "训练结束或相关题库已删除。"),
        B("返回复习", () => setSession(null)),
      );
    const r = data.records?.[e.key] || {},
      correct = same(picked, e.q.answer);
    function partial(p) {
      setSession({ ...session, ...p });
    }
    function submit() {
      if (submitted || !picked.length) return;
      const eventId = session.id + ":" + session.index,
        events = data.events || [];
      if (events.some((e) => e.id === eventId)) {
        setSubmitted(true);
        partial({ submitted: true, picked });
        return;
      }
      const next = {
        ...data,
        records: {
          ...data.records,
          [e.key]: review(r, { correct, uncertain, reason }),
        },
        events: [
          ...events,
          { id: eventId, key: e.key, at: Date.now(), correct, uncertain },
        ].slice(-10000),
      };
      if (update(next)) {
        setSubmitted(true);
        partial({ picked, submitted: true, uncertain, reason });
      }
    }
    return h(
      "section",
      null,
      h(
        "div",
        { className: "v12-tools" },
        h("h2", null, `专项训练 ${session.index + 1} / ${session.keys.length}`),
        B("退出并保留进度", () =>
          partial({ paused: true, picked, submitted, uncertain, reason }),
        ),
        B("结束本次训练", () => {
          if (
            window.confirm("结束后保留已提交结果，不再保留本次队列，是否继续？")
          )
            setSession(null);
        }),
      ),
      h(
        "small",
        null,
        `${e.paper.title} · 来源题号${e.q.originalNo || e.q.no} · ${TYPES[e.q.qtype]} · ${e.q.score}分`,
      ),
      material(e.material),
      h("div", { className: "v12-stem" }, T(e.q.stem)),
      ...(e.q.images || []).map((src, i) =>
        h("img", { key: i, src, alt: "题图", className: "v12-image" }),
      ),
      h(
        "div",
        { className: "v12-options" },
        ...e.q.options.map((o) =>
          B(
            h(React.Fragment, null, o.key + ". ", T(o.text)),
            () => {
              if (submitted) return;
              const a =
                typeOf(e.q) === "multi"
                  ? picked.includes(o.key)
                    ? picked.filter((k) => k !== o.key)
                    : [...picked, o.key]
                  : [o.key];
              setPicked(a);
              partial({ picked: a });
            },
            {
              key: o.key,
              disabled: submitted,
              className: picked.includes(o.key) ? "selected" : "",
            },
          ),
        ),
      ),
      h(
        "div",
        { className: "v12-tools" },
        h(
          "label",
          null,
          h("input", {
            type: "checkbox",
            checked: uncertain,
            disabled: submitted,
            onChange: (e) => {
              setUncertain(e.target.checked);
              partial({ uncertain: e.target.checked });
            },
          }),
          "这题没把握（答对也安排复习）",
        ),
        B(r.favorite ? "取消收藏" : "收藏", () =>
          update({
            ...data,
            records: {
              ...data.records,
              [e.key]: { ...r, favorite: !r.favorite },
            },
          }),
        ),
      ),
      !submitted && B("提交本题", submit, { disabled: !picked.length }),
      submitted &&
        h(
          "div",
          { className: "v12-explanation" },
          h("strong", null, correct ? "本题答对" : "本题答错"),
          h("p", null, "正确答案：" + e.q.answer.join(" ")),
          T(
            (e.q.explanation || "原文件未提供解析").replace(
              /^\s*【[^】]+】\s*/,
              "",
            ),
          ),
          h(
            "p",
            null,
            "下次复习：" +
              new Date(
                (data.records?.[e.key] || {}).dueAt || Date.now(),
              ).toLocaleDateString(),
          ),
        ),
      h(
        "label",
        null,
        "错因 ",
        S(
          reason,
          (v) => {
            setReason(v);
            if (submitted)
              update({
                ...data,
                records: {
                  ...data.records,
                  [e.key]: { ...data.records?.[e.key], reason: v },
                },
              });
            else partial({ reason: v });
          },
          [
            ["", "未标注"],
            ["知识点不清", "知识点不清"],
            ["审题失误", "审题失误"],
            ["计算或单位", "计算或单位"],
            ["记忆混淆", "记忆混淆"],
            ["猜对未掌握", "猜对未掌握"],
          ],
          "错因",
        ),
      ),
      h(
        "label",
        null,
        "复习笔记（自动保存）",
        h("textarea", {
          rows: 3,
          value: r.note || "",
          onChange: (v) =>
            update({
              ...data,
              records: {
                ...data.records,
                [e.key]: { ...r, note: v.target.value },
              },
            }),
        }),
      ),
      h(
        "div",
        { className: "v12-tools" },
        B(
          session.index + 1 >= session.keys.length ? "完成训练" : "下一题",
          () => {
            if (
              !submitted &&
              !window.confirm("尚未提交，跳过不记录得分，是否继续？")
            )
              return;
            if (session.index + 1 >= session.keys.length) {
              setSession(null);
              notice("训练完成，记录已保存");
            } else
              setSession({
                ...session,
                index: session.index + 1,
                picked: [],
                submitted: false,
                uncertain: false,
                reason: "",
              });
          },
        ),
      ),
    );
  }
  return function Center() {
    const load = () => {
      const raw = api.get("v12-study", null) || {};
      return {
        records: raw.records || {},
        events: raw.events || [],
        settings: raw.settings || { goal: 20, examDate: "" },
      };
    };
    const [open, setOpen] = useState(false),
      [tab, setTab] = useState("dashboard"),
      [papers, setPapers] = useState([]),
      [data, setData] = useState(load),
      [session, setSessionState] = useState(() => api.get("v12-session", null));
    useEffect(() => {
      document.body.classList.toggle("v12-open", open);
      return () => document.body.classList.remove("v12-open");
    }, [open]);
    useEffect(() => {
      const f = () => setPapers(api.papers());
      window.addEventListener("v13-reference-updated", f);
      return () => window.removeEventListener("v13-reference-updated", f);
    }, []);
    const entries = useMemo(
      () => catalog(papers, api.progress, data.records),
      [papers, data],
    );
    function update(next) {
      if (!api.set("v12-study", next)) return false;
      setData(next);
      return true;
    }
    function setSession(next) {
      if (!api.set("v12-session", next)) return;
      setSessionState(next);
    }
    function start(list) {
      if (!list.length) return notice("没有符合条件的题目");
      if (
        session &&
        !window.confirm("已有未完成训练，将替换当前队列，是否继续？")
      )
        return;
      setSession({
        id:
          "train_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
        keys: list.map((e) => e.key),
        index: 0,
        picked: [],
        submitted: false,
      });
      setTab("library");
    }
    return h(
      React.Fragment,
      null,
      B(
        "备考中心 · 模块分值与复习",
        () => {
          const match = /\/exam\/([^/?#]+)/.exec(
            location.hash || location.pathname,
          );
          if (match) {
            const p = api.progress(decodeURIComponent(match[1]));
            if (p.started && !p.submitted)
              return notice(
                "模考进行中，请先交卷再打开含答案的备考功能",
                {},
                "error",
              );
          }
          document.getElementById("v11-notices")?.replaceChildren();
          setPapers(api.papers());
          setData(load());
          setOpen(true);
        },
        { className: "v12-launch print:hidden" },
      ),
      open &&
        h(
          "div",
          {
            className: "v12-overlay",
            role: "dialog",
            "aria-modal": true,
            "aria-label": "国网备考中心",
          },
          h(
            "div",
            { className: "v12-shell" },
            h(
              "header",
              { className: "v12-header" },
              h(
                "div",
                null,
                h("b", null, "国网备考中心"),
                h("small", null, "V2.1 · 自动同步，独立时政题库"),
              ),
              B("关闭备考中心", () => setOpen(false)),
            ),
            h(
              "nav",
              { className: "v12-tabs" },
              ...[
                ["dashboard", "今日备考"],
                ["library", "错题与专项"],
                ["modules", "科目与分值核对"],
                ["reference", "企业文化来源库"],
                ["calculator", "科学计算器"],
                ["prompt", "Word制作提示词"],
              ].map(([id, label]) =>
                B(label, () => setTab(id), {
                  key: id,
                  className: tab === id ? "active" : "",
                }),
              ),
            ),
            h(
              "main",
              { className: "v12-main", key: tab },
              session?.paused &&
                h(
                  "div",
                  { className: "v12-band" },
                  "有未完成训练。",
                  B("继续上次训练", () => {
                    setSession({ ...session, paused: false });
                    setTab("library");
                  }),
                ),
              tab === "dashboard" &&
                h(Dashboard, { entries, data, update, start }),
              tab === "modules" && h(Modules, { papers, setPapers }),
              tab === "reference" && h(ReferencePanel, { papers }),
              tab === "calculator" && h(Calculator, { embedded: true }),
              tab === "prompt" && h(Prompt, { papers }),
              tab === "library" &&
                (session && !session.paused
                  ? h(Practice, { entries, data, update, session, setSession })
                  : h(Library, { entries, data, update, start })),
            ),
          ),
        ),
    );
  };
}
