const FOLDER_KEY = 'exam-desktop:v14-folders';

function loadFolders() {
  try {
    const list = JSON.parse(localStorage.getItem(FOLDER_KEY) || '[]');
    return Array.isArray(list) ? list.filter((x) => typeof x === 'string' && x.trim()) : [];
  } catch (e) {
    return [];
  }
}

function saveFolders(list) {
  try {
    localStorage.setItem(FOLDER_KEY, JSON.stringify(list));
  } catch (e) {}
}

export function createLibraryManager(React, api) {
  const h = React.createElement;
  const { useState, useEffect } = React;

  function readPapers() {
    return (api.papers() || []).map((p, i) => ({
      id: p.id,
      title: p.title,
      folder: p.folder || '',
      order: Number.isFinite(p.order) ? p.order : i,
      questions: (p.items || []).filter((q) => q.type === 'question').length,
    }));
  }

  return function LibraryManager() {
    const [open, setOpen] = useState(false);
    const [rows, setRows] = useState([]);
    const [folders, setFolders] = useState([]);
    const [selected, setSelected] = useState('__all__');
    const [draft, setDraft] = useState('');
    const [renameTarget, setRenameTarget] = useState(null);
    const [renameValue, setRenameValue] = useState('');
    const [deleteTarget, setDeleteTarget] = useState(null);
    const [dragId, setDragId] = useState(null);
    const [toast, setToast] = useState('');
    const [dirty, setDirty] = useState(false);

    useEffect(() => {
      const onOpen = () => {
        const ps = readPapers();
        const stored = loadFolders();
        const derived = ps.map((p) => p.folder || '').filter(Boolean);
        setRows(ps);
        setFolders([...new Set([...stored, ...derived])].filter((f) => f && f !== '未分类'));
        setSelected('__all__');
        setDraft('');
        setRenameTarget(null);
        setDeleteTarget(null);
        setDirty(false);
        setToast('');
        setOpen(true);
      };
      window.addEventListener('v14-open-library', onOpen);
      return () => window.removeEventListener('v14-open-library', onOpen);
    }, []);

    function touch() {
      setDirty(true);
      setToast('');
    }

    function patch(id, key, value) {
      setRows((list) => list.map((r) => (r.id === id ? { ...r, [key]: value } : r)));
      touch();
    }

    function maxOrder(list, folder) {
      return list.filter((r) => (r.folder || '') === folder).reduce((m, r) => Math.max(m, r.order), -1);
    }

    function moveTo(id, folder) {
      setRows((list) => {
        if ((list.find((r) => r.id === id) || {}).folder === folder) return list;
        const next = list.map((r) => (r.id === id ? { ...r, folder, order: maxOrder(list, folder) + 1 } : r));
        return next;
      });
      touch();
    }

    function reorder(id, dir) {
      setRows((list) => {
        const folder = (list.find((r) => r.id === id) || {}).folder || '';
        const group = list.filter((r) => (r.folder || '') === folder).sort((a, b) => a.order - b.order || a.title.localeCompare(b.title, 'zh'));
        const i = group.findIndex((r) => r.id === id);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= group.length) return list;
        const a = group[i];
        const b = group[j];
        return list.map((r) => {
          if (r.id === a.id) return { ...r, order: b.order };
          if (r.id === b.id) return { ...r, order: a.order };
          return r;
        });
      });
      touch();
    }

    function addFolder() {
      const name = draft.trim();
      if (!name) return;
      if (name !== '未分类' && !folders.includes(name)) setFolders((f) => [...f, name]);
      setDraft('');
      setSelected(name === '未分类' ? '' : name);
      touch();
    }

    function commitRename() {
      const from = renameTarget;
      const to = renameValue.trim();
      setRenameTarget(null);
      if (from === null || !to || to === from) return;
      setFolders((list) => list.map((f) => (f === from ? to : f)));
      setRows((list) => list.map((r) => ((r.folder || '') === from ? { ...r, folder: to } : r)));
      if (selected === from) setSelected(to);
      touch();
    }

    function removeFolder(name) {
      setFolders((list) => list.filter((f) => f !== name));
      setRows((list) => list.map((r) => ((r.folder || '') === name ? { ...r, folder: '' } : r)));
      if (selected === name) setSelected('');
      setDeleteTarget(null);
      touch();
    }

    function save() {
      const papers = api.papers() || [];
      const byId = new Map(rows.map((r) => [r.id, r]));
      const keeps = folders.filter((f) => f !== '未分类');
      saveFolders(keeps);
      const ordered = [...rows].sort((a, b) => {
        const fa = a.folder || '';
        const fb = b.folder || '';
        return fa.localeCompare(fb, 'zh') || a.order - b.order;
      });
      const orderMap = new Map();
      ordered.forEach((r) => {
        const f = r.folder || '';
        const n = orderMap.get(f) || 0;
        orderMap.set(f, n + 1);
        orderMap.set('#' + r.id, n);
      });
      const next = papers.map((p) => {
        const r = byId.get(p.id);
        if (!r) return p;
        return {
          ...p,
          title: (r.title || '').trim() || p.title,
          folder: r.folder || '',
          order: orderMap.get('#' + r.id) || 0,
        };
      });
      api.savePapers(next);
      setDirty(false);
      setToast('已保存');
      try {
        window.dispatchEvent(new Event('v12-papers-updated'));
      } catch (e) {}
    }

    function close() {
      if (dirty && !window.confirm('还有未保存的修改，确定关闭吗？')) return;
      setOpen(false);
    }

    const allFolders = ['', ...folders.filter((f) => f && f !== '未分类')];
    const counts = {};
    rows.forEach((r) => {
      const f = r.folder || '';
      counts[f] = (counts[f] || 0) + 1;
    });
    const visible =
      selected === '__all__'
        ? [...rows].sort((a, b) => (a.folder || '').localeCompare(b.folder || '', 'zh') || (a.order || 0) - (b.order || 0))
        : rows.filter((r) => (r.folder || '') === (selected === '' ? '' : selected)).sort((a, b) => (a.order || 0) - (b.order || 0));
    const currentLabel = selected === '__all__' ? '全部试卷' : selected || '未分类';

    function folderRow(key, label, count, custom) {
      const active = selected === key;
      const isEditing = custom && renameTarget === key;
      return h(
        'div',
        {
          key: 'f:' + (key || 'none'),
          className: 'v14-lib-folder' + (active ? ' is-active' : '') + (dragId ? ' is-drop' : ''),
          onClick: () => setSelected(key === '未分类' ? '' : key),
          onDragOver: (e) => {
            e.preventDefault();
          },
          onDrop: (e) => {
            e.preventDefault();
            if (dragId) moveTo(dragId, key === '未分类' ? '' : key);
            setDragId(null);
          },
        },
        h('span', { className: 'v14-lib-folder-icon' }, custom ? '▸' : '≡'),
        isEditing
          ? h('input', {
              className: 'v14-lib-folder-input',
              autoFocus: true,
              value: renameValue,
              onClick: (e) => e.stopPropagation(),
              onChange: (e) => setRenameValue(e.target.value),
              onBlur: commitRename,
              onKeyDown: (e) => {
                if (e.key === 'Enter') commitRename();
                if (e.key === 'Escape') setRenameTarget(null);
              },
            })
          : h('span', { className: 'v14-lib-folder-name' }, label),
        h('em', { className: 'v14-lib-count' }, String(count)),
        custom &&
          !isEditing &&
          h('button', {
            type: 'button',
            className: 'v14-lib-mini',
            title: '重命名文件夹',
            onClick: (e) => {
              e.stopPropagation();
              setRenameTarget(key);
              setRenameValue(key);
            },
          }, '✎'),
        custom &&
          h('button', {
            type: 'button',
            className: 'v14-lib-mini v14-lib-danger' + (deleteTarget === key ? ' is-armed' : ''),
            title: deleteTarget === key ? '再点一次确认删除' : '删除文件夹',
            onClick: (e) => {
              e.stopPropagation();
              if (deleteTarget === key) removeFolder(key);
              else {
                setDeleteTarget(key);
                setTimeout(() => setDeleteTarget((v) => (v === key ? null : v)), 2600);
              }
            },
          }, deleteTarget === key ? '确认？' : '✕'),
      );
    }

    function restoreBackup() {
      const input = document.querySelector('.v14-backup-btn input');
      if (!input) {
        alert('没有找到导入入口，请在首页顶部点“导入备份文件”。');
        return;
      }
      input.click();
    }

    function exportBackup() {
      const btn = document.querySelector('.v11-backup button');
      if (btn) btn.click();
      else alert('没有找到导出入口，请在首页顶部点“备份题库和记录”。');
    }

    const dialog = h(
      'div',
      { className: 'v14-lib-overlay', role: 'dialog', 'aria-modal': true, 'aria-label': '题库管理' },
      h(
        'div',
        { className: 'v14-lib-shell' },
        h(
          'header',
          { className: 'v14-lib-header' },
          h('div', null, h('b', null, '题库管理'), h('small', null, '像电脑文件夹一样：新建文件夹、拖动试卷归类、改名、排序')),
          h('div', { className: 'v14-lib-header-actions' }, h('span', { className: 'v14-lib-status' }, dirty ? '有未保存的修改' : toast || '数据保存在 文档\\Guowang_Exam'), h('button', { type: 'button', onClick: restoreBackup }, '导入备份'), h('button', { type: 'button', onClick: exportBackup }, '导出备份'), h('button', { type: 'button', className: 'v14-lib-primary', onClick: save }, '保存'), h('button', { type: 'button', onClick: close }, '关闭')),
        ),
        h(
          'div',
          { className: 'v14-lib-body' },
          h(
            'aside',
            { className: 'v14-lib-side' },
            h('div', { className: 'v14-lib-side-title' }, '文件夹'),
            folderRow('__all__', '全部试卷', rows.length, false),
            folderRow('', '未分类', counts[''] || 0, false),
            ...folders.filter((f) => f && f !== '未分类').map((f) => folderRow(f, f, counts[f] || 0, true)),
            h(
              'div',
              { className: 'v14-lib-new' },
              h('input', {
                value: draft,
                placeholder: '新文件夹名称',
                onChange: (e) => setDraft(e.target.value),
                onKeyDown: (e) => {
                  if (e.key === 'Enter') addFolder();
                },
              }),
              h('button', { type: 'button', onClick: addFolder }, '新建'),
            ),
            h('p', { className: 'v14-lib-tip' }, '把右侧试卷行直接拖到某个文件夹，也能在“移动到”里选。'),
          ),
          h(
            'main',
            { className: 'v14-lib-main' },
            h('div', { className: 'v14-lib-main-head' }, h('strong', null, currentLabel), h('span', null, `${visible.length} 套`)),
            visible.length === 0 && h('p', { className: 'v14-lib-empty' }, '这个文件夹里还没有试卷。可从“全部试卷”里拖进来，或导入新题库。'),
            ...visible.map((r) =>
              h(
                'div',
                {
                  key: r.id,
                  className: 'v14-lib-row' + (dragId === r.id ? ' is-drag' : ''),
                  draggable: true,
                  onDragStart: () => setDragId(r.id),
                  onDragEnd: () => setDragId(null),
                },
                h('span', { className: 'v14-lib-grip', title: '拖动到左侧文件夹' }, '⠿'),
                h('div', { className: 'v14-lib-row-main' },
                  h('input', {
                    className: 'v14-lib-title',
                    value: r.title,
                    'aria-label': '试卷名称',
                    onChange: (e) => patch(r.id, 'title', e.target.value),
                  }),
                  h('div', { className: 'v14-lib-row-meta' },
                    h('span', null, `${r.questions} 题`),
                    h('label', null, '移动到',
                      h('select', {
                        value: r.folder || '',
                        onChange: (e) => moveTo(r.id, e.target.value),
                      },
                        ...allFolders.map((f) => h('option', { value: f, key: f || 'none' }, f || '未分类')),
                      ),
                    ),
                  ),
                ),
                h('div', { className: 'v14-lib-row-actions' },
                  h('button', { type: 'button', onClick: () => reorder(r.id, -1), title: '在本文件夹内上移' }, '↑'),
                  h('button', { type: 'button', onClick: () => reorder(r.id, 1), title: '在本文件夹内下移' }, '↓'),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    return h(React.Fragment, null, open && dialog);
  };
}
