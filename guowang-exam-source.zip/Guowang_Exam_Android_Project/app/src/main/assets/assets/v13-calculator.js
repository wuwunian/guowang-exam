export function createCalculator(React) {
  const h = React.createElement;
  const { useState, useRef } = React;

  return function Calculator({ onClose, embedded = false }) {
    const [expression, setExpression] = useState('');
    const [result, setResult] = useState('0');
    const [error, setError] = useState('');
    const [angle, setAngle] = useState('DEG');
    const [position, setPosition] = useState({
      x: Math.max(8, window.innerWidth - 360),
      y: 80,
    });
    const panel = useRef(null);
    const drag = useRef(null);

    function calculate(text) {
      const degree = angle === 'DEG';
      const src = text
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/−/g, '-')
        .replace(/π/g, 'PI')
        .replace(/√/g, 'sqrt')
        .replace(/\^/g, '**');
      if (!/^[0-9+\-*/().,%\sA-Za-z]*$/.test(src)) throw Error('含有不支持的字符');
      const toRad = (x) => (degree ? (x * Math.PI) / 180 : x);
      const fromRad = (x) => (degree ? (x * 180) / Math.PI : x);
      const sin = (x) => Math.sin(toRad(x));
      const cos = (x) => Math.cos(toRad(x));
      const tan = (x) => Math.tan(toRad(x));
      const asin = (x) => fromRad(Math.asin(x));
      const acos = (x) => fromRad(Math.acos(x));
      const atan = (x) => fromRad(Math.atan(x));
      const sqrt = (x) => Math.sqrt(x);
      const PI = Math.PI;
      const value = Function('sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sqrt', 'PI', '"use strict";return (' + src + ')')(
        sin, cos, tan, asin, acos, atan, sqrt, PI,
      );
      if (typeof value !== 'number' || !Number.isFinite(value)) throw Error('无法计算');
      return String(Math.round(value * 1e10) / 1e10);
    }

    function press(key) {
      setError('');
      if (key === 'ac') {
        setExpression('');
        setResult('0');
        return;
      }
      if (key === 'back') {
        setExpression((v) => v.slice(0, -1));
        return;
      }
      if (key === '=') {
        try {
          const next = calculate(expression || '0');
          setResult(next);
          setExpression(next);
        } catch (e) {
          setError(e.message);
        }
        return;
      }
      if (key === '±') {
        setExpression((v) => (v.startsWith('-(') ? v.slice(2, -1) : '-(' + (v || '0') + ')'));
        return;
      }
      if (key === 'deg') {
        setAngle((v) => (v === 'DEG' ? 'RAD' : 'DEG'));
        return;
      }
      const map = { '√': '√(', 'sin': 'sin(', 'cos': 'cos(', 'tan': 'tan(', 'asin': 'asin(', 'acos': 'acos(', 'atan': 'atan(', 'π': 'π' };
      setExpression((v) => v + (map[key] || key));
    }

    const keys = [
      ['AC', 'ac'], ['⌫', 'back'], ['%', '%'], ['÷', '÷'],
      ['7', '7'], ['8', '8'], ['9', '9'], ['×', '×'],
      ['4', '4'], ['5', '5'], ['6', '6'], ['−', '−'],
      ['1', '1'], ['2', '2'], ['3', '3'], ['+', '+'],
      ['±', '±'], ['0', '0'], ['.', '.'], ['=', '='],
    ];

    const sciKeys = [
      ['sin', 'sin'], ['cos', 'cos'], ['tan', 'tan'], ['DEG', 'deg'],
      ['asin', 'asin'], ['acos', 'acos'], ['atan', 'atan'], ['π', 'π'],
      ['√', '√'], ['x²', '^2'], ['(', '('], [')', ')'],
    ];

    const header = h(
      'header',
      {
        className: 'v13-calc-header',
        onPointerDown: (e) => {
          if (embedded || e.target.closest('button')) return;
          drag.current = { sx: e.clientX, sy: e.clientY, x: position.x, y: position.y };
          e.currentTarget.setPointerCapture(e.pointerId);
        },
        onPointerMove: (e) => {
          if (!drag.current) return;
          setPosition({
            x: Math.max(0, Math.min(window.innerWidth - (panel.current?.offsetWidth || 340), drag.current.x + e.clientX - drag.current.sx)),
            y: Math.max(0, Math.min(window.innerHeight - 60, drag.current.y + e.clientY - drag.current.sy)),
          });
        },
        onPointerUp: (e) => {
          drag.current = null;
          if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        },
      },
      h('div', null, h('b', null, '计算器'), h('small', null, angle === 'DEG' ? '角度制 DEG · 可拖动' : '弧度制 RAD · 可拖动')),
      onClose && h('button', { type: 'button', onClick: onClose }, '关闭'),
    );

    return h(
      'aside',
      {
        ref: panel,
        className: 'v13-calculator ' + (embedded ? 'v13-calc-embedded' : 'v13-calc-floating'),
        style: embedded ? undefined : { left: position.x, top: position.y },
        role: embedded ? undefined : 'dialog',
        'aria-label': '计算器',
      },
      header,
      h(
        'div',
        { className: 'v13-calc-body' },
        h('output', { className: 'v13-calc-result', 'aria-label': '计算结果' }, result),
        h('div', { className: 'v14-calc-expression' }, expression || '0'),
        h('div', { className: 'v14-calc-sci' }, ...sciKeys.map(([label, key]) =>
          h('button', {
            key,
            type: 'button',
            className: key === 'deg' ? 'v14-calc-mode' : '',
            onClick: () => press(key),
          }, label === 'DEG' ? (angle === 'DEG' ? 'DEG' : 'RAD') : label),
        )),
        h('div', { className: 'v14-calc-keys' }, ...keys.map(([label, key]) =>
          h('button', {
            key,
            type: 'button',
            className: key === '=' ? 'v14-equals' : '',
            onClick: () => press(key),
          }, label),
        )),
        error && h('div', { className: 'v13-calc-error', role: 'alert' }, error),
      ),
    );
  };
}
