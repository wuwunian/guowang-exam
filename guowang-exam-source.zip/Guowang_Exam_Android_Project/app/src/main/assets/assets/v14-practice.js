const KEY = "exam-desktop:v14-practice:";
const MEM = "exam-desktop:v14-memory:";
const PROG = "exam-desktop:progress:";
const POLITICS = "时事政治";

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function writeJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {}
}

export function subsetItems(paperId, items) {
  const all = (items || []).filter((q) => q.type === "question");
  const cfg = readJSON(KEY + paperId, null);
  if (!cfg || !Array.isArray(cfg.nos) || cfg.nos.length === 0) return all;
  const byNo = new Map(all.map((q) => [String(q.no), q]));
  const list = cfg.nos.map((n) => byNo.get(String(n))).filter(Boolean);
  return list.length ? list : all;
}

function sameAnswer(a, b) {
  const x = (a || []).slice().sort().join("");
  const y = (b || []).slice().sort().join("");
  return x.length > 0 && x === y;
}

export function answerState(q, answer, judged) {
  const selected = (answer || []).slice().sort();
  const correct = (q.answer || []).slice().sort();
  const committed = q.qtype !== "multi" || !!judged;
  if (!selected.length || !committed)
    return {
      attempted: false,
      correct: false,
      reason: "new",
      missing: [],
      extra: [],
    };
  const missing = correct.filter((x) => !selected.includes(x));
  const extra = selected.filter((x) => !correct.includes(x));
  if (!missing.length && !extra.length)
    return {
      attempted: true,
      correct: true,
      reason: "correct",
      missing,
      extra,
    };
  if (q.qtype === "multi") {
    return {
      attempted: true,
      correct: false,
      reason:
        missing.length && extra.length
          ? "multi_mixed"
          : extra.length
            ? "multi_extra"
            : "multi_missed",
      missing,
      extra,
    };
  }
  return {
    attempted: true,
    correct: false,
    reason: q.qtype === "judge" ? "judge_wrong" : "single_wrong",
    missing,
    extra,
  };
}

function analyze(paper) {
  const prog = readJSON(PROG + paper.id, {}) || {};
  const answers = prog.answers || {};
  const known = readJSON(MEM + paper.id, { known: [], unknown: [] }) || {
    known: [],
    unknown: [],
  };
  const knownSet = new Set((known.known || []).map(String));
  const unknownSet = new Set((known.unknown || []).map(String));
  const rows = (paper.items || [])
    .filter((q) => q.type === "question")
    .map((q) => {
      const key = String(q.no);
      const ans = answers[key] || [];
      const state = answerState(q, ans, prog.judged && prog.judged[key]);
      return {
        q,
        answered: state.attempted,
        correct: state.correct,
        reason: state.reason,
        missing: state.missing,
        extra: state.extra,
        known: knownSet.has(String(q.no)),
        unknown: unknownSet.has(String(q.no)),
      };
    });
  return { rows, knownSet, unknownSet };
}

function memorySets(paperId) {
  const raw = readJSON(MEM + paperId, {}) || {};
  return {
    multiMissed: new Set((raw.multiMissed || []).map(String)),
    judgeWrong: new Set((raw.judgeWrong || []).map(String)),
    singleWrong: new Set((raw.singleWrong || []).map(String)),
    review: raw.review || {},
  };
}

export function captureMistakes(paper) {
  const { rows } = analyze(paper);
  const store = readJSON(MEM + paper.id, {}) || {};
  const multiMissed = new Set((store.multiMissed || []).map(String));
  const multiWrong = new Set((store.multiWrong || []).map(String));
  const judgeWrong = new Set((store.judgeWrong || []).map(String));
  const singleWrong = new Set((store.singleWrong || []).map(String));
  const before = [multiMissed.size, multiWrong.size, judgeWrong.size, singleWrong.size].join(',');
  rows.filter((r) => isPolitics(r.q) && r.answered && !r.correct).forEach((r) => {
    const key = String(r.q.no);
    if (r.q.qtype === 'multi') {
      multiWrong.add(key);
      if (r.missing.length) multiMissed.add(key);
    } else if (r.q.qtype === 'judge') judgeWrong.add(key);
    else if (r.q.qtype === 'single') singleWrong.add(key);
  });
  const after = [multiMissed.size, multiWrong.size, judgeWrong.size, singleWrong.size].join(',');
  if (before !== after) {
    writeJSON(MEM + paper.id, {
      ...store,
      multiMissed: [...multiMissed],
      multiWrong: [...multiWrong],
      judgeWrong: [...judgeWrong],
      singleWrong: [...singleWrong],
      at: Date.now(),
    });
    return true;
  }
  return false;
}

function isPolitics(q) {
  return (q.module || "").trim() === POLITICS;
}

function dueToday(review, no) {
  const row = review[String(no)];
  return !!row && Number(row.due || 0) <= Date.now();
}

function poolOf(paper, source, types) {
  const { rows } = analyze(paper);
  const saved = memorySets(paper.id);
  return rows
    .filter((r) => types.includes(r.q.qtype))
    .filter((r) => {
      if (source === "new") return !r.answered;
      if (source === "wrong") return r.answered && !r.correct;
      if (source === "weak") return !r.answered || !r.correct;
      if (source === "unknown") return r.unknown;
      if (source === "known") return r.known;
      if (source === "politics_all") return isPolitics(r.q);
      if (source === "politics_priority") {
        if (!isPolitics(r.q)) return false;
        if (r.q.qtype === "multi") return true;
        if (r.reason === "judge_wrong" || r.reason === "single_wrong")
          return true;
        return (
          saved.judgeWrong.has(String(r.q.no)) ||
          saved.singleWrong.has(String(r.q.no)) ||
          r.unknown
        );
      }
      if (source === "multi_all")
        return isPolitics(r.q) && r.q.qtype === "multi";
      if (source === "multi_missed")
        return (
          isPolitics(r.q) &&
          r.q.qtype === "multi" &&
          (r.reason === "multi_missed" ||
            r.reason === "multi_mixed" ||
            saved.multiMissed.has(String(r.q.no)))
        );
      if (source === "judge_wrong")
        return (
          isPolitics(r.q) &&
          r.q.qtype === "judge" &&
          (r.reason === "judge_wrong" || saved.judgeWrong.has(String(r.q.no)))
        );
      if (source === "single_wrong")
        return (
          isPolitics(r.q) &&
          r.q.qtype === "single" &&
          (r.reason === "single_wrong" || saved.singleWrong.has(String(r.q.no)))
        );
      if (source === "politics_due")
        return isPolitics(r.q) && (r.unknown || dueToday(saved.review, r.q.no));
      return true;
    })
    .map((r) => r.q);
}

export function politicsStats(paper) {
  const { rows } = analyze(paper);
  const saved = memorySets(paper.id);
  const politics = rows.filter((r) => isPolitics(r.q));
  const has = (r, set, reason) =>
    set.has(String(r.q.no)) || r.reason === reason;
  return {
    total: politics.length,
    multi: politics.filter((r) => r.q.qtype === "multi").length,
    multiMissed: politics.filter(
      (r) =>
        r.q.qtype === "multi" &&
        (saved.multiMissed.has(String(r.q.no)) ||
          r.reason === "multi_missed" ||
          r.reason === "multi_mixed"),
    ).length,
    judgeWrong: politics.filter(
      (r) => r.q.qtype === "judge" && has(r, saved.judgeWrong, "judge_wrong"),
    ).length,
    singleWrong: politics.filter(
      (r) =>
        r.q.qtype === "single" && has(r, saved.singleWrong, "single_wrong"),
    ).length,
    due: politics.filter((r) => r.unknown || dueToday(saved.review, r.q.no))
      .length,
  };
}

export function createPracticeStarter(React, api) {
  const h = React.createElement;
  const { useState, useEffect } = React;
  const TYPES = [
    ["single", "单选题"],
    ["multi", "多选题"],
    ["judge", "判断题"],
  ];
  const COUNTS = [20, 50, 100, 9999];
  const SOURCES = [
    ["all", "全部题"],
    ["new", "没做过的"],
    ["wrong", "做错过的"],
    ["weak", "错题+没做过"],
    ["unknown", "没记住的"],
  ];
  const POLITICS_SOURCES = [
    ["politics_priority", "时政重点组合"],
    ["multi_all", "全部多选"],
    ["multi_missed", "多选漏选"],
    ["judge_wrong", "判断错题"],
    ["single_wrong", "单选错题"],
    ["politics_due", "今天该复习"],
    ["politics_all", "全部时政"],
  ];

  return function PracticeStarter() {
    const [open, setOpen] = useState(false);
    const [paper, setPaper] = useState(null);
    const [count, setCount] = useState(50);
    const [shuffle, setShuffle] = useState(true);
    const [types, setTypes] = useState(["single", "multi", "judge"]);
    const [source, setSource] = useState("all");
    const [mode, setMode] = useState("test");
    const [onStart, setOnStart] = useState(null);
    const [inCulture, setInCulture] = useState(
      !!window.__v14ActivePaperId || /\/culture\//.test(location.hash || ""),
    );
    const [memory, setMemory] = useState(null);
    const [revealed, setRevealed] = useState(false);
    const [recalled, setRecalled] = useState([]);
    const [finished, setFinished] = useState(false);

    useEffect(() => {
      const sync = () => {
        const match = /\/culture\/([^/?#]+)/.exec(location.hash || "");
        if (match) {
          window.__v14ActivePaperId = decodeURIComponent(match[1]);
          setInCulture(true);
        }
      };
      const enter = (event) => {
        window.__v14ActivePaperId = event.detail?.paperId || window.__v14ActivePaperId;
        setInCulture(true);
      };
      const leave = () => {
        window.__v14ActivePaperId = null;
        setInCulture(false);
      };
      window.addEventListener("hashchange", sync);
      window.addEventListener("popstate", sync);
      window.addEventListener("v14-enter-practice", enter);
      window.addEventListener("v14-leave-practice", leave);
      sync();
      return () => {
        window.removeEventListener("hashchange", sync);
        window.removeEventListener("popstate", sync);
        window.removeEventListener("v14-enter-practice", enter);
        window.removeEventListener("v14-leave-practice", leave);
      };
    }, []);

    useEffect(() => {
      window.__v14PracticeStart = (p, start) => {
        const cfg = readJSON(KEY + p.id, null);
        setPaper(p);
        setCount(cfg && cfg.count ? cfg.count : 50);
        setShuffle(cfg ? !!cfg.shuffle : true);
        setTypes(
          cfg && Array.isArray(cfg.types) && cfg.types.length
            ? cfg.types
            : ["single", "multi", "judge"],
        );
        setSource("all");
        setMode("test");
        setOnStart(() => start);
        setOpen(true);
      };
      return () => {
        delete window.__v14PracticeStart;
      };
    }, []);

    function toggleType(t) {
      setTypes((old) => {
        if (old.includes(t)) {
          const next = old.filter((x) => x !== t);
          return next.length ? next : old;
        }
        return [...old, t];
      });
    }

    function currentPaper() {
      const match = /\/culture\/([^/?#]+)/.exec(location.hash || "");
      const activeId = window.__v14ActivePaperId || (match ? decodeURIComponent(match[1]) : "");
      if (!activeId) return null;
      return (
        (api.papers() || []).find(
          (x) => x.id === activeId,
        ) || null
      );
    }

    useEffect(() => {
      if (!inCulture) return undefined;
      const scan = () => {
        const current = currentPaper();
        if (current) captureMistakes(current);
      };
      scan();
      const timer = setInterval(scan, 500);
      return () => clearInterval(timer);
    }, [inCulture]);

    const pool = paper ? poolOf(paper, source, types) : [];
    const take = Math.min(count, pool.length);
    const total = paper
      ? (paper.items || []).filter((q) => q.type === "question").length
      : 0;
    const politics = paper
      ? politicsStats(paper)
      : {
          total: 0,
          multi: 0,
          multiMissed: 0,
          judgeWrong: 0,
          singleWrong: 0,
          due: 0,
        };

    function pick() {
      let list = [...pool];
      if (shuffle) {
        for (let i = list.length - 1; i > 0; i -= 1) {
          const j = Math.floor(Math.random() * (i + 1));
          [list[i], list[j]] = [list[j], list[i]];
        }
      } else {
        list.sort((a, b) => Number(a.no) - Number(b.no));
      }
      return list.slice(0, take);
    }

    function start() {
      if (!paper) return;
      const list = pick();
      if (!list.length) {
        alert("这个范围里没有题目，换一个选题范围试试。");
        return;
      }
      writeJSON(KEY + paper.id, {
        nos: list.map((q) => q.no),
        count: list.length,
        shuffle: !!shuffle,
        types,
        source,
        at: Date.now(),
      });
      const cb = onStart;
      const useMemory = mode === "memory";
      setOpen(false);
      if (useMemory) {
        setFinished(false);
        setRevealed(false);
        setRecalled([]);
        setMemory({ paper, nos: list.map((q) => q.no), i: 0 });
        return;
      }
      if (cb) cb(paper);
      else location.reload();
    }

    function mark(kind, reason) {
      if (!memory) return;
      const cur = memory.paper.items.find(
        (q) => String(q.no) === String(memory.nos[memory.i]),
      );
      const store = readJSON(MEM + memory.paper.id, {
        known: [],
        unknown: [],
      }) || { known: [], unknown: [] };
      const known = new Set((store.known || []).map(String));
      const unknown = new Set((store.unknown || []).map(String));
      const multiMissed = new Set((store.multiMissed || []).map(String));
      const judgeWrong = new Set((store.judgeWrong || []).map(String));
      const singleWrong = new Set((store.singleWrong || []).map(String));
      const review = { ...(store.review || {}) };
      const key = String(cur.no);
      if (kind === "known") {
        known.add(key);
        unknown.delete(key);
      } else {
        unknown.add(key);
        known.delete(key);
      }
      if (reason === "multi_missed" || reason === "multi_mixed")
        multiMissed.add(key);
      if (reason === "judge_wrong") judgeWrong.add(key);
      if (reason === "single_wrong") singleWrong.add(key);
      const old = review[key] || {};
      const streak = kind === "known" ? Number(old.streak || 0) + 1 : 0;
      const days =
        kind === "known" ? [1, 3, 7, 14, 30][Math.min(streak - 1, 4)] : 0;
      review[key] = {
        streak,
        last: Date.now(),
        due: Date.now() + days * 86400000,
        result: kind,
        reason: reason || "",
      };
      writeJSON(MEM + memory.paper.id, {
        ...store,
        known: [...known],
        unknown: [...unknown],
        multiMissed: [...multiMissed],
        judgeWrong: [...judgeWrong],
        singleWrong: [...singleWrong],
        review,
        at: Date.now(),
      });
      setRevealed(false);
      setRecalled([]);
      if (memory.i + 1 >= memory.nos.length) setFinished(true);
      else setMemory((m) => ({ ...m, i: m.i + 1 }));
    }

    useEffect(() => {
      if (!memory || finished) return;
      const onKey = (e) => {
        if (e.key === " ") {
          e.preventDefault();
          setRevealed(true);
        } else if ((e.key === "1" || e.key === "2") && revealed) {
          const cur = memory.paper.items.find(
            (q) => String(q.no) === String(memory.nos[memory.i]),
          );
          if (!cur) return;
          const state = answerState(cur, recalled, true);
          const correct = state.attempted && state.correct;
          const reason = state.attempted
            ? state.reason
            : cur.qtype === "multi"
              ? "multi_missed"
              : cur.qtype === "judge"
                ? "judge_wrong"
                : "single_wrong";
          if (e.key === "1" && correct) mark("known", reason);
          if (e.key === "2" && !correct) mark("unknown", reason);
        }
        else if (e.key === "ArrowRight")
          setMemory((m) =>
            m && m.i + 1 < m.nos.length ? { ...m, i: m.i + 1 } : m,
          );
        else if (e.key === "ArrowLeft")
          setMemory((m) => (m && m.i > 0 ? { ...m, i: m.i - 1 } : m));
      };
      window.addEventListener("keydown", onKey);
      return () => window.removeEventListener("keydown", onKey);
    }, [memory, finished, revealed, recalled]);

    const dialog =
      open && paper
        ? h(
            "div",
            {
              className: "v14-lib-overlay",
              role: "dialog",
              "aria-modal": true,
              "aria-label": "刷题设置",
            },
            h(
              "div",
              { className: "v14-practice-shell" },
              h(
                "header",
                { className: "v14-lib-header" },
                h(
                  "div",
                  null,
                  h("b", null, "刷题设置"),
                  h("small", null, paper.title),
                ),
                h(
                  "button",
                  { type: "button", onClick: () => setOpen(false) },
                  "取消",
                ),
              ),
              h(
                "div",
                { className: "v14-practice-body" },
                h(
                  "p",
                  { className: "v14-lib-note" },
                  `本题库共 ${total} 道题，当前范围 ${pool.length} 道，本次将练 ${take} 道。`,
                ),
                politics.total > 0 &&
                  h(
                    "section",
                    { className: "v15-politics-box" },
                    h(
                      "div",
                      { className: "v15-politics-title" },
                      h("strong", null, "时事政治强化"),
                      h(
                        "span",
                        null,
                        `共 ${politics.total} 题 · 多选 ${politics.multi} · 待复习 ${politics.due}`,
                      ),
                    ),
                    h(
                      "div",
                      { className: "v15-politics-metrics" },
                      h(
                        "div",
                        null,
                        h("b", null, politics.multiMissed),
                        h("span", null, "多选漏选"),
                      ),
                      h(
                        "div",
                        null,
                        h("b", null, politics.judgeWrong),
                        h("span", null, "判断错题"),
                      ),
                      h(
                        "div",
                        null,
                        h("b", null, politics.singleWrong),
                        h("span", null, "单选错题"),
                      ),
                    ),
                    h(
                      "div",
                      { className: "v14-practice-chips" },
                      ...POLITICS_SOURCES.map(([key, label]) =>
                        h(
                          "button",
                          {
                            key,
                            type: "button",
                            className: source === key ? "is-on" : "",
                            onClick: () => {
                              setSource(key);
                              if (key === "multi_all" || key === "multi_missed")
                                setTypes(["multi"]);
                              else setTypes(["single", "multi", "judge"]);
                            },
                          },
                          label,
                        ),
                      ),
                    ),
                    h(
                      "p",
                      { className: "v14-lib-tip" },
                      "“时政重点组合”包含全部多选题，以及做错或没记住的判断题、单选题；订正后仍保留历史薄弱记录。",
                    ),
                  ),
                h(
                  "div",
                  { className: "v14-practice-group" },
                  h("strong", null, "其他练习范围"),
                  h(
                    "div",
                    { className: "v14-practice-chips" },
                    ...SOURCES.map(([key, label]) =>
                      h(
                        "button",
                        {
                          key,
                          type: "button",
                          className: source === key ? "is-on" : "",
                          onClick: () => setSource(key),
                        },
                        label,
                      ),
                    ),
                  ),
                ),
                h(
                  "div",
                  { className: "v14-practice-group" },
                  h("strong", null, "每次练多少题"),
                  h(
                    "div",
                    { className: "v14-practice-chips" },
                    ...COUNTS.map((c) =>
                      h(
                        "button",
                        {
                          key: c,
                          type: "button",
                          className: count === c ? "is-on" : "",
                          onClick: () => setCount(c),
                        },
                        c === 9999 ? "全部" : String(c),
                      ),
                    ),
                  ),
                ),
                h(
                  "div",
                  { className: "v14-practice-group" },
                  h("strong", null, "出题顺序"),
                  h(
                    "div",
                    { className: "v14-practice-chips" },
                    h(
                      "button",
                      {
                        type: "button",
                        className: shuffle ? "is-on" : "",
                        onClick: () => setShuffle(true),
                      },
                      "随机打乱",
                    ),
                    h(
                      "button",
                      {
                        type: "button",
                        className: !shuffle ? "is-on" : "",
                        onClick: () => setShuffle(false),
                      },
                      "按原顺序",
                    ),
                  ),
                ),
                h(
                  "div",
                  { className: "v14-practice-group" },
                  h("strong", null, "题型"),
                  h(
                    "div",
                    { className: "v14-practice-chips" },
                    ...TYPES.map(([key, label]) =>
                      h(
                        "button",
                        {
                          key,
                          type: "button",
                          className: types.includes(key) ? "is-on" : "",
                          onClick: () => toggleType(key),
                        },
                        label,
                      ),
                    ),
                  ),
                ),
                h(
                  "div",
                  { className: "v14-practice-group" },
                  h("strong", null, "练习方式"),
                  h(
                    "div",
                    { className: "v14-practice-chips" },
                    h(
                      "button",
                      {
                        type: "button",
                        className: mode === "test" ? "is-on" : "",
                        onClick: () => setMode("test"),
                      },
                      "做题模式",
                    ),
                    h(
                      "button",
                      {
                        type: "button",
                        className: mode === "memory" ? "is-on" : "",
                        onClick: () => setMode("memory"),
                      },
                      "背题模式（看解析）",
                    ),
                  ),
                ),
                h(
                  "p",
                  { className: "v14-lib-tip" },
                  mode === "memory"
                    ? "背题模式：先看题干自己回想，点“显示答案”核对，再标记“记住了 / 没记住”；没记住的下次可在范围里选“没记住的”重练。"
                    : "每次开始都会重新抽取一组；这一组会固定下来，退出再进仍是同一组。",
                ),
                h(
                  "div",
                  { className: "v14-practice-actions" },
                  h(
                    "button",
                    {
                      type: "button",
                      className: "v14-lib-primary",
                      onClick: start,
                    },
                    mode === "memory" ? "开始背题" : "开始刷题",
                  ),
                ),
              ),
            ),
          )
        : null;

    let memView = null;
    if (memory && !finished) {
      const q = memory.paper.items.find(
        (x) => String(x.no) === String(memory.nos[memory.i]),
      );
      if (q) {
        const recall = answerState(q, recalled, true);
        const recallCorrect = recall.attempted && recall.correct;
        const recallReason = recall.attempted
          ? recall.reason
          : q.qtype === "multi"
            ? "multi_missed"
            : q.qtype === "judge"
              ? "judge_wrong"
              : "single_wrong";
        const toggleRecall = (key) => {
          if (revealed) return;
          setRecalled((old) => {
            if (q.qtype !== "multi") return [key];
            return old.includes(key)
              ? old.filter((x) => x !== key)
              : [...old, key];
          });
        };
        const answerText = (q.answer || []).map((k) => {
          const opt = (q.options || []).find((o) => o.key === k);
          return opt ? `${k}. ${opt.text}` : k;
        });
        memView = h(
          "div",
          { className: "v14-lib-overlay", role: "dialog", "aria-modal": true },
          h(
            "div",
            { className: "v14-memory-shell" },
            h(
              "header",
              { className: "v14-lib-header" },
              h(
                "div",
                null,
                h("b", null, "背题模式"),
                h(
                  "small",
                  null,
                  `${memory.i + 1} / ${memory.nos.length} · ${q.qtype === "multi" ? "多选" : q.qtype === "judge" ? "判断" : "单选"} · ${q.module || "未分类"} · ${q.score} 分`,
                ),
              ),
              h(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setMemory(null);
                    setFinished(false);
                  },
                },
                "退出",
              ),
            ),
            h(
              "div",
              { className: "v14-memory-body" },
              h(
                "div",
                { className: "v14-memory-stem" },
                h("b", null, `第 ${q.no} 题`),
                h("span", null, q.stem || q.text || ""),
              ),
              h(
                "div",
                { className: "v14-memory-options" },
                ...(q.options || []).map((o) =>
                  h(
                    "button",
                    {
                      key: o.key,
                      type: "button",
                      disabled: revealed,
                      "aria-pressed": recalled.includes(o.key),
                      onClick: () => toggleRecall(o.key),
                      className:
                        "v14-memory-option" +
                        (recalled.includes(o.key) ? " is-picked" : "") +
                        (revealed && (q.answer || []).includes(o.key)
                          ? " is-answer"
                          : "") +
                        (revealed && recall.extra.includes(o.key)
                          ? " is-wrong"
                          : "") +
                        (revealed && recall.missing.includes(o.key)
                          ? " is-missed"
                          : ""),
                    },
                    `${o.key}. ${o.text}`,
                  ),
                ),
              ),
              revealed &&
                h(
                  "div",
                  { className: "v14-memory-answer" },
                  h(
                    "div",
                    null,
                    h("strong", null, "答案："),
                    answerText.join("；"),
                  ),
                  h(
                    "div",
                    {
                      className: recallCorrect
                        ? "v15-recall-ok"
                        : "v15-recall-bad",
                    },
                    recallCorrect
                      ? "你回忆正确。"
                      : !recalled.length
                        ? "本题没有作答，已按“没记住”处理。"
                        : q.qtype === "multi" && recall.missing.length
                          ? `漏 · 漏选：${recall.missing.join("、")}${recall.extra.length ? `；多选：${recall.extra.join("、")}` : ""}`
                          : `你的回忆：${recalled.join("、")}，需要强化。`,
                  ),
                  q.explanation &&
                    h(
                      "div",
                      { className: "v14-memory-explain" },
                      h("strong", null, "解析："),
                      h("span", null, q.explanation),
                    ),
                ),
              h(
                "div",
                { className: "v14-memory-actions" },
                !revealed &&
                  h(
                    "button",
                    {
                      type: "button",
                      className: "v14-lib-primary",
                      onClick: () => setRevealed(true),
                    },
                    recalled.length
                      ? "提交回忆并核对（空格）"
                      : "不会，直接看答案（空格）",
                  ),
                revealed &&
                  h(
                    "button",
                    {
                      type: "button",
                      className: recallCorrect
                        ? "v14-memory-known"
                        : "v14-memory-unknown",
                      onClick: () =>
                        mark(recallCorrect ? "known" : "unknown", recallReason),
                    },
                    recallCorrect
                      ? "回忆正确，下一题（1）"
                      : "加入强化，下一题（2）",
                  ),
                h(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setRecalled([]);
                      setRevealed(false);
                      setMemory((m) => (m.i > 0 ? { ...m, i: m.i - 1 } : m));
                    },
                    disabled: memory.i === 0,
                  },
                  "上一题",
                ),
                h(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setRecalled([]);
                      setRevealed(false);
                      setMemory((m) =>
                        m.i + 1 < m.nos.length ? { ...m, i: m.i + 1 } : m,
                      );
                    },
                    disabled: memory.i + 1 >= memory.nos.length,
                  },
                  "跳过",
                ),
              ),
            ),
          ),
        );
      }
    }

    let doneView = null;
    if (memory && finished) {
      const store = readJSON(MEM + memory.paper.id, {
        known: [],
        unknown: [],
      }) || { known: [], unknown: [] };
      doneView = h(
        "div",
        { className: "v14-lib-overlay", role: "dialog", "aria-modal": true },
        h(
          "div",
          { className: "v14-memory-shell v14-memory-done" },
          h("h3", null, "这一轮背完了"),
          h(
            "p",
            null,
            `本轮 ${memory.nos.length} 题；题库累计已记住 ${(store.known || []).length} 题，待巩固 ${(store.unknown || []).length} 题。`,
          ),
          h(
            "div",
            { className: "v15-done-metrics" },
            h("span", null, `多选漏选 ${(store.multiMissed || []).length}`),
            h("span", null, `判断错题 ${(store.judgeWrong || []).length}`),
            h("span", null, `单选错题 ${(store.singleWrong || []).length}`),
          ),
          h(
            "div",
            { className: "v14-memory-actions" },
            h(
              "button",
              {
                type: "button",
                className: "v14-lib-primary",
                onClick: () => {
                  const politicsOnly =
                    source.startsWith("politics_") ||
                    [
                      "multi_all",
                      "multi_missed",
                      "judge_wrong",
                      "single_wrong",
                    ].includes(source);
                  const list = memory.paper.items.filter(
                    (q) =>
                      (store.unknown || [])
                        .map(String)
                        .includes(String(q.no)) &&
                      (!politicsOnly || isPolitics(q)),
                  );
                  if (!list.length) {
                    alert("没有待巩固的题了");
                    return;
                  }
                  setFinished(false);
                  setRevealed(false);
                  setRecalled([]);
                  setMemory({
                    paper: memory.paper,
                    nos: list.map((q) => q.no),
                    i: 0,
                  });
                },
              },
              `再背 ${(store.unknown || []).length} 道没记住的`,
            ),
            h(
              "button",
              {
                type: "button",
                onClick: () => {
                  setMemory(null);
                  setFinished(false);
                },
              },
              "关闭",
            ),
          ),
        ),
      );
    }

    const activePaper = inCulture ? currentPaper() : null;
    const activePolitics = activePaper ? politicsStats(activePaper).total : 0;
    const fabs =
      inCulture && !open && !memory
        ? h(
            "div",
            { className: "v14-practice-fabs" },
            activePolitics > 0 &&
              h(
                "button",
                {
                  type: "button",
                  className: "v14-practice-fab v15-politics-fab",
                  onClick: () => {
                    const p = currentPaper();
                    if (!p) return;
                    setPaper(p);
                    setCount(20);
                    setShuffle(true);
                    setTypes(["single", "multi", "judge"]);
                    setSource("politics_priority");
                    setMode("memory");
                    setOnStart(null);
                    setOpen(true);
                  },
                },
                "时政强化",
              ),
            h(
              "button",
              {
                type: "button",
                className: "v14-practice-fab",
                onClick: () => {
                  const p = currentPaper();
                  if (!p) return;
                  window.__v14PracticeStart(p, null);
                },
              },
              "换一组 / 刷题设置",
            ),
            h(
              "button",
              {
                type: "button",
                className: "v14-practice-fab",
                onClick: () => {
                  const p = currentPaper();
                  if (!p) return;
                  setPaper(p);
                  setCount(20);
                  setShuffle(true);
                  setTypes(["single", "multi", "judge"]);
                  setSource("weak");
                  setMode("memory");
                  setOnStart(null);
                  setOpen(true);
                },
              },
              "背题模式",
            ),
          )
        : null;

    return h(React.Fragment, null, fabs, dialog, memView, doneView);
  };
}
