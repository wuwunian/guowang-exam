const PREFIX = 'exam-desktop:';
const CONFIG_KEY = PREFIX + 'v20-sync';
const SYNCED = (key) => key.startsWith(PREFIX) && key !== CONFIG_KEY && !key.startsWith(PREFIX + 'v20-');

function readConfig() {
  try {
    const value = JSON.parse(localStorage.getItem(CONFIG_KEY) || '{}');
    return {
      url: value.url || '',
      anonKey: value.anonKey || '',
      session: value.session || null,
      deviceId: value.deviceId || ('device-' + crypto.randomUUID()),
      deviceName: value.deviceName || (/Mobi|Android|iPhone/i.test(navigator.userAgent) ? '手机' : '电脑'),
      meta: value.meta || {},
      autoSync: !!value.autoSync,
      lastSync: value.lastSync || 0,
    };
  } catch {
    return { url: '', anonKey: '', session: null, deviceId: 'device-' + crypto.randomUUID(), deviceName: '设备', meta: {}, autoSync: false, lastSync: 0 };
  }
}

function saveConfig(config) {
  localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
}

function parse(raw, fallback) {
  try { return JSON.parse(raw); } catch { return fallback; }
}

function hash(raw) {
  let value = 2166136261;
  for (let i = 0; i < raw.length; i += 1) {
    value ^= raw.charCodeAt(i);
    value = Math.imul(value, 16777619);
  }
  return (value >>> 0).toString(16).padStart(8, '0') + ':' + raw.length;
}

function localDocuments() {
  const docs = new Map();
  for (let i = 0; i < localStorage.length; i += 1) {
    const full = localStorage.key(i);
    if (!full || !SYNCED(full)) continue;
    const suffix = full.slice(PREFIX.length);
    const raw = localStorage.getItem(full) || '';
    if (suffix === 'papers') {
      const papers = parse(raw, []);
      if (!Array.isArray(papers)) continue;
      docs.set('paper-index', JSON.stringify(papers.map((paper) => paper.id)));
      papers.forEach((paper) => {
        if (paper && paper.id) docs.set('paper:' + paper.id, JSON.stringify(paper));
      });
    } else {
      docs.set('storage:' + suffix, raw);
    }
  }
  return docs;
}

function applyDocuments(docs, replace = false) {
  if (replace) {
    const remove = [];
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i);
      if (key && SYNCED(key)) remove.push(key);
    }
    remove.forEach((key) => localStorage.removeItem(key));
  }
  const index = parse(docs.get('paper-index') || '[]', []);
  if (Array.isArray(index)) {
    const papers = index.map((id) => parse(docs.get('paper:' + id), null)).filter(Boolean);
    if (papers.length || index.length === 0) localStorage.setItem(PREFIX + 'papers', JSON.stringify(papers));
  }
  docs.forEach((raw, key) => {
    if (key.startsWith('storage:')) localStorage.setItem(PREFIX + key.slice(8), raw);
  });
  window.dispatchEvent(new Event('v12-papers-updated'));
  window.dispatchEvent(new Event('v13-reference-updated'));
}

function mergeSets(a, b) {
  return [...new Set([...(Array.isArray(a) ? a : []), ...(Array.isArray(b) ? b : [])].map(String))];
}

function mergeMemory(localRaw, remoteRaw) {
  const a = parse(localRaw, {}), b = parse(remoteRaw, {});
  const review = { ...(b.review || {}) };
  Object.entries(a.review || {}).forEach(([key, row]) => {
    if (!review[key] || Number(row.last || 0) >= Number(review[key].last || 0)) review[key] = row;
  });
  return JSON.stringify({
    ...b,
    ...a,
    known: mergeSets(a.known, b.known),
    unknown: mergeSets(a.unknown, b.unknown),
    multiMissed: mergeSets(a.multiMissed, b.multiMissed),
    multiWrong: mergeSets(a.multiWrong, b.multiWrong),
    judgeWrong: mergeSets(a.judgeWrong, b.judgeWrong),
    singleWrong: mergeSets(a.singleWrong, b.singleWrong),
    review,
    at: Math.max(Number(a.at || 0), Number(b.at || 0)),
  });
}

function mergeStudy(localRaw, remoteRaw) {
  const a = parse(localRaw, {}), b = parse(remoteRaw, {});
  const records = { ...(b.records || {}) };
  Object.entries(a.records || {}).forEach(([key, row]) => {
    const old = records[key];
    const rowTime = Number(row.updatedAt || row.lastAt || row.last || 0);
    const oldTime = Number(old?.updatedAt || old?.lastAt || old?.last || 0);
    if (!old || rowTime >= oldTime) records[key] = row;
  });
  const events = [...(b.events || []), ...(a.events || [])];
  const unique = [...new Map(events.map((event) => [event.id || JSON.stringify(event), event])).values()]
    .sort((x, y) => Number(x.at || 0) - Number(y.at || 0))
    .slice(-10000);
  return JSON.stringify({ ...b, ...a, records, events: unique });
}

function paperTime(raw) {
  const paper = parse(raw, {});
  return Number(paper.updatedAt || paper.revisedAt || paper.importedAt || 0);
}

function progressTime(raw) {
  const progress = parse(raw, {});
  return Number(progress.finishedAt || progress.updatedAt || progress.startedAt || 0);
}

function mergeDocument(key, localRaw, remoteRaw) {
  if (key === 'paper-index') {
    return { raw: JSON.stringify(mergeSets(parse(localRaw, []), parse(remoteRaw, []))), conflict: false };
  }
  if (key.startsWith('paper:')) {
    const lt = paperTime(localRaw), rt = paperTime(remoteRaw);
    if (lt !== rt) return { raw: lt >= rt ? localRaw : remoteRaw, conflict: false };
    return { raw: localRaw, conflict: true };
  }
  if (/^storage:v14-memory:/.test(key)) return { raw: mergeMemory(localRaw, remoteRaw), conflict: false };
  if (key === 'storage:v12-study') return { raw: mergeStudy(localRaw, remoteRaw), conflict: false };
  if (/^storage:progress:/.test(key)) {
    const lt = progressTime(localRaw), rt = progressTime(remoteRaw);
    if (lt !== rt) return { raw: lt >= rt ? localRaw : remoteRaw, conflict: false };
    return { raw: localRaw, conflict: true };
  }
  return { raw: localRaw, conflict: true };
}

function downloadJson(name, value) {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

class SyncClient {
  constructor(config) { this.config = config; }
  cleanUrl() { return this.config.url.trim().replace(/\/+$/, ''); }
  async request(path, options = {}, auth = true) {
    const headers = { apikey: this.config.anonKey.trim(), 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (auth && this.config.session?.access_token) headers.Authorization = 'Bearer ' + this.config.session.access_token;
    const response = await fetch(this.cleanUrl() + path, { ...options, headers });
    const text = await response.text();
    const body = text ? parse(text, text) : null;
    if (!response.ok) throw new Error(typeof body === 'string' ? body : body?.msg || body?.message || body?.error_description || ('请求失败 ' + response.status));
    return body;
  }
  async signup(email, password) {
    const body = await this.request('/auth/v1/signup', { method: 'POST', body: JSON.stringify({ email, password }) }, false);
    if (body?.session) this.config.session = body.session;
    return body;
  }
  async login(email, password) {
    const body = await this.request('/auth/v1/token?grant_type=password', { method: 'POST', body: JSON.stringify({ email, password }) }, false);
    this.config.session = body;
    return body;
  }
  async ensureSession() {
    if (!this.config.session) throw new Error('请先登录');
    const expires = Number(this.config.session.expires_at || 0) * 1000;
    if (expires && expires > Date.now() + 60000) return;
    const refresh = this.config.session.refresh_token;
    if (!refresh) throw new Error('登录已失效，请重新登录');
    this.config.session = await this.request('/auth/v1/token?grant_type=refresh_token', {
      method: 'POST', body: JSON.stringify({ refresh_token: refresh }),
    }, false);
    saveConfig(this.config);
  }
  userId() {
    const token = this.config.session?.access_token;
    if (!token) return '';
    try {
      let payload = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      payload += '='.repeat((4 - payload.length % 4) % 4);
      return JSON.parse(atob(payload)).sub || '';
    } catch { return ''; }
  }
  async rows() {
    await this.ensureSession();
    return await this.request('/rest/v1/sync_documents?select=key,value,updated_at,device_id&order=key.asc');
  }
  async upsert(docs) {
    await this.ensureSession();
    if (!docs.length) return [];
    const userId = this.userId();
    if (!userId) throw new Error('无法识别登录账号，请重新登录');
    const rows = docs.map(([key, raw]) => ({
      user_id: userId, key, value: { raw }, device_id: this.config.deviceId,
    }));
    const result = [];
    for (let start = 0; start < rows.length; start += 20) {
      const part = await this.request('/rest/v1/sync_documents?on_conflict=user_id,key', {
        method: 'POST',
        headers: { Prefer: 'resolution=merge-duplicates,return=representation' },
        body: JSON.stringify(rows.slice(start, start + 20)),
      });
      if (Array.isArray(part)) result.push(...part);
    }
    return result;
  }
}

async function sync(config, mode, notify) {
  if (!navigator.onLine) throw new Error('当前没有网络，离线数据已保留');
  const client = new SyncClient(config);
  const local = localDocuments();
  const rows = await client.rows();
  const remote = new Map(rows.map((row) => [row.key, { raw: row.value?.raw ?? '', updatedAt: row.updated_at || '' }]));
  notify(`本机 ${local.size} 项，云端 ${remote.size} 项，正在处理……`);
  if (mode === 'upload') {
    await client.upsert([...local]);
  } else if (mode === 'download') {
    downloadJson('国网考试系统_云端覆盖前备份_' + new Date().toISOString().slice(0, 10) + '.json', Object.fromEntries(local));
    applyDocuments(new Map([...remote].map(([key, row]) => [key, row.raw])), true);
  } else {
    const chosen = new Map();
    const uploads = [];
    const conflicts = [];
    const keys = new Set([...local.keys(), ...remote.keys()]);
    for (const key of keys) {
      const l = local.get(key), r = remote.get(key), meta = config.meta[key];
      if (l === undefined) { chosen.set(key, r.raw); continue; }
      if (!r) { chosen.set(key, l); uploads.push([key, l]); continue; }
      if (l === r.raw) { chosen.set(key, l); continue; }
      const localChanged = !meta || meta.hash !== hash(l);
      const remoteChanged = !meta || meta.remoteAt !== r.updatedAt;
      if (!localChanged && remoteChanged) chosen.set(key, r.raw);
      else if (localChanged && !remoteChanged) { chosen.set(key, l); uploads.push([key, l]); }
      else {
        const merged = mergeDocument(key, l, r.raw);
        chosen.set(key, merged.raw);
        uploads.push([key, merged.raw]);
        if (merged.conflict) conflicts.push({ key, local: l, remote: r.raw });
      }
    }
    if (conflicts.length) {
      downloadJson('国网考试系统_同步冲突备份_' + Date.now() + '.json', conflicts);
      notify(`发现 ${conflicts.length} 项同时修改，已保留本机版本并下载冲突备份。`);
    }
    applyDocuments(chosen, false);
    await client.upsert(uploads);
  }
  const finalRows = await client.rows();
  const finalLocal = localDocuments();
  config.meta = {};
  finalRows.forEach((row) => {
    const raw = finalLocal.get(row.key);
    if (raw !== undefined) config.meta[row.key] = { hash: hash(raw), remoteAt: row.updated_at || '' };
  });
  config.lastSync = Date.now();
  config.autoSync = true;
  saveConfig(config);
  return { local: finalLocal.size, remote: finalRows.length };
}

function mount() {
  let config = readConfig();
  saveConfig(config);
  let busy = false;
  const root = document.createElement('div');
  root.id = 'v20-sync-root';
  document.body.append(root);
  root.innerHTML = `
    <button class="v20-sync-launch" type="button">手机同步</button>
    <div class="v20-sync-overlay" hidden>
      <section class="v20-sync-panel" role="dialog" aria-modal="true" aria-label="手机与电脑同步">
        <header><div><b>手机与电脑同步</b><small>V2.1 · 自动上传并双向合并</small></div><button type="button" data-action="close">关闭</button></header>
        <main>
          <div class="v20-sync-status"></div>
          <label>项目地址<input data-field="url" placeholder="https://你的项目.supabase.co"></label>
          <label>公开 anon key<textarea data-field="anonKey" rows="3" placeholder="只填写公开 anon key，不要填写 service_role key"></textarea></label>
          <div class="v20-sync-account">
            <label>邮箱<input data-field="email" type="email" autocomplete="username"></label>
            <label>密码<input data-field="password" type="password" autocomplete="current-password" minlength="8"></label>
          </div>
          <label>设备名称<input data-field="deviceName" placeholder="例如：我的电脑、我的手机"></label>
          <div class="v20-sync-actions v20-auth-actions">
            <button type="button" data-action="signup">注册</button>
            <button type="button" data-action="login" class="primary">登录</button>
          </div>
          <div class="v20-sync-actions v20-data-actions">
            <button type="button" data-action="merge" class="primary">双向安全合并（推荐）</button>
            <button type="button" data-action="upload">以本机数据上传</button>
            <button type="button" data-action="download">下载云端并替换本机</button>
            <button type="button" data-action="reload">刷新查看数据</button>
            <button type="button" data-action="logout">退出账号</button>
          </div>
          <label class="v20-auto"><input type="checkbox" data-field="autoSync"> 电脑和手机自动上传并双向安全合并</label>
          <details><summary>现在需要手动同步吗？</summary><p>通常不需要。登录成功后会立即合并，之后电脑和手机每30秒、重新联网或回到软件时自动上传并合并。首次使用也可先在题库最完整的电脑选择“以本机数据上传”，再在手机选择“下载云端并替换本机”。</p></details>
          <p class="v20-sync-note">必须先按安装说明创建免费云项目并执行数据库脚本。密码不会保存；软件只保存登录令牌。同步冲突不会静默丢弃，会下载冲突备份。</p>
        </main>
      </section>
    </div>`;
  const overlay = root.querySelector('.v20-sync-overlay');
  const status = root.querySelector('.v20-sync-status');
  const field = (name) => root.querySelector(`[data-field="${name}"]`);
  function refresh() {
    field('url').value = config.url;
    field('anonKey').value = config.anonKey;
    field('deviceName').value = config.deviceName;
    field('autoSync').checked = config.autoSync;
    const logged = !!config.session?.access_token;
    root.classList.toggle('is-logged', logged);
    status.textContent = logged
      ? `已登录 · ${config.session.user?.email || '同步账号'} · 上次同步：${config.lastSync ? new Date(config.lastSync).toLocaleString() : '尚未同步'}`
      : '尚未登录。离线题库和作答不受影响。';
  }
  function readFields() {
    config.url = field('url').value.trim();
    config.anonKey = field('anonKey').value.trim();
    config.deviceName = field('deviceName').value.trim() || config.deviceName;
    config.autoSync = field('autoSync').checked;
    saveConfig(config);
  }
  function message(text, error = false) {
    status.textContent = text;
    status.classList.toggle('is-error', error);
  }
  async function run(action) {
    if (busy) return;
    readFields();
    if (!config.url || !config.anonKey) return message('请先填写项目地址和公开 anon key。', true);
    busy = true;
    root.classList.add('is-busy');
    let finalMessage = '';
    let finalError = false;
    try {
      const client = new SyncClient(config);
      if (action === 'signup' || action === 'login') {
        const email = field('email').value.trim(), password = field('password').value;
        if (!email || password.length < 8) throw new Error('请输入有效邮箱和至少8位密码');
        const result = action === 'signup' ? await client.signup(email, password) : await client.login(email, password);
        config = client.config;
        saveConfig(config);
        if (!config.session) finalMessage = '注册成功。请先在邮箱中完成确认，然后回来登录。';
        else {
          config.autoSync = true;
          saveConfig(config);
          const result = await sync(config, 'merge', (text) => message(text));
          finalMessage = `登录成功并已自动合并：本机 ${result.local} 项，云端 ${result.remote} 项。`;
        }
      } else {
        const result = await sync(config, action, (text) => message(text));
        finalMessage = `同步完成：本机 ${result.local} 项，云端 ${result.remote} 项。建议刷新页面查看最新数据。`;
      }
    } catch (error) {
      finalMessage = error.message || String(error);
      finalError = true;
    } finally {
      busy = false;
      root.classList.remove('is-busy');
      refresh();
      if (finalMessage) message(finalMessage, finalError);
    }
  }
  root.querySelector('.v20-sync-launch').addEventListener('click', () => { overlay.hidden = false; refresh(); });
  root.addEventListener('click', (event) => {
    const action = event.target.closest('[data-action]')?.dataset.action;
    if (!action) return;
    if (action === 'close') overlay.hidden = true;
    else if (action === 'reload') location.reload();
    else if (action === 'logout') {
      config.session = null;
      config.autoSync = false;
      saveConfig(config);
      refresh();
    } else if (action === 'download') {
      if (confirm('云端数据将替换本机同步数据。系统会先下载本机恢复文件，确定继续吗？')) run(action);
    } else run(action);
  });
  field('autoSync').addEventListener('change', readFields);
  setInterval(() => {
    if (config.autoSync && config.session && navigator.onLine && !busy) run('merge');
  }, 30000);
  window.addEventListener('online', () => {
    if (config.autoSync && config.session && !busy) run('merge');
  });
  window.addEventListener('focus', () => {
    if (config.autoSync && config.session && navigator.onLine && !busy) run('merge');
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && config.autoSync && config.session && navigator.onLine && !busy) run('merge');
  });
  refresh();
  setTimeout(() => {
    if (config.autoSync && config.session && navigator.onLine && !busy) run('merge');
  }, 1500);
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  }
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
}

export { localDocuments, applyDocuments, mergeDocument, mergeMemory, mergeStudy, hash };
