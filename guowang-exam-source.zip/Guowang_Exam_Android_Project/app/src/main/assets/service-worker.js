const CACHE = 'guowang-exam-v2.1.0';
const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/index-C7F1kn8q.js',
  './assets/index-Cyay3XgR.css',
  './assets/v11.css',
  './assets/v12.css',
  './assets/v13.css',
  './assets/v20.css',
  './assets/v20-sync.js',
  './assets/v11-core.js',
  './assets/v12-logic.js',
  './assets/v12-prompt.js',
  './assets/v12-ui.js',
  './assets/v13-calculator.js',
  './assets/v13-match.js',
  './assets/v13-math.js',
  './assets/v13-reference-ui.js',
  './assets/v14-library.js',
  './assets/v14-practice.js',
  './icons/pwa-192x192.png',
  './icons/pwa-512x512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fresh = fetch(event.request).then((response) => {
        if (response.ok) caches.open(CACHE).then((cache) => cache.put(event.request, response.clone()));
        return response;
      }).catch(() => cached);
      return cached || fresh;
    }),
  );
});
