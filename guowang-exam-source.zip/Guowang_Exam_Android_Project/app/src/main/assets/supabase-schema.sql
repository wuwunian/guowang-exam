-- 国网考试系统 V2.0：跨设备同步表
-- 在 Supabase -> SQL Editor 中完整执行一次。

create table if not exists public.sync_documents (
  user_id uuid not null references auth.users(id) on delete cascade,
  key text not null,
  value jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

alter table public.sync_documents enable row level security;

drop policy if exists "Users manage own sync documents" on public.sync_documents;
create policy "Users manage own sync documents"
on public.sync_documents
for all
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create or replace function public.set_sync_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists sync_documents_updated_at on public.sync_documents;
create trigger sync_documents_updated_at
before update on public.sync_documents
for each row execute function public.set_sync_updated_at();

grant select, insert, update, delete on table public.sync_documents to authenticated;
revoke all on table public.sync_documents from anon;

