# 国网考试系统 APK 工程

1. 安装 Android Studio（推荐稳定版）并安装 Android SDK 34。
2. 用 Android Studio 打开本目录。
3. 等待 Gradle 同步完成。
4. 选择 `Build > Build APK(s)`。
5. APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。

工程已内置 V2.1.5 手机端页面，包含电脑/手机同步、时事政治题库、漏选显示和复制按钮。
